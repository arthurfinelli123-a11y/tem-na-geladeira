import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/store/auth";
import type {
  Profile, PantryItem, CatalogItem, SavedRecipe, Collection, ShoppingList, ShoppingItem,
  Conversation, ChatMessage, Subscription, UsageRow,
} from "@/lib/types";

function useUid() { return useAuth((s) => s.user?.id ?? null); }
function fail(e: unknown) {
  console.error(e);
  toast.error("Não foi possível concluir a ação. Tente novamente.");
}
const unwrap = <T,>(r: { data: T | null; error: unknown }): T => {
  if (r.error) throw r.error;
  return r.data as T;
};

/* ───────── Perfil ───────── */
export function useProfile() {
  const uid = useUid();
  return useQuery({
    queryKey: ["profile", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("profiles").select("*").eq("id", uid!).maybeSingle()) as Profile | null,
  });
}
export function useSaveProfile(silent = false) {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: Partial<Profile>) => unwrap(await supabase.from("profiles").update(patch).eq("id", uid!).select().single()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["profile", uid] }); if (!silent) toast.success("Perfil salvo!"); },
    onError: fail,
  });
}

/* ───────── Catálogo (autocomplete) ───────── */
export function useCatalog() {
  return useQuery({
    queryKey: ["catalog"], staleTime: Infinity,
    queryFn: async () => unwrap(await supabase.from("ingredient_catalog").select("id,name,category").order("name")) as CatalogItem[],
  });
}

/* ───────── Despensa ───────── */
export function usePantry() {
  const uid = useUid();
  return useQuery({
    queryKey: ["pantry", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("pantry_items").select("*").eq("user_id", uid!).order("created_at", { ascending: false })) as PantryItem[],
  });
}
export function useAddPantry() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (items: { name: string; category?: string; quantity?: number | null; unit?: string | null; excluded?: boolean }[]) => {
      const rows = items.map((i) => ({
        user_id: uid!, name: i.name.trim(), category: i.category ?? "outros",
        quantity: i.quantity ?? null, unit: i.unit ?? null, excluded: i.excluded ?? false,
      }));
      unwrap(await supabase.from("pantry_items").upsert(rows, { onConflict: "user_id,name,excluded" }).select());
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pantry", uid] }),
    onError: fail,
  });
}
export function useUpdatePantry() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...patch }: Partial<PantryItem> & { id: string }) =>
      unwrap(await supabase.from("pantry_items").update(patch).eq("id", id).select()),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pantry", uid] }),
    onError: fail,
  });
}
export function useRemovePantry() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => unwrap(await supabase.from("pantry_items").delete().eq("id", id).select()),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pantry", uid] }),
    onError: fail,
  });
}

/* ───────── Receitas ───────── */
export function useRecipes() {
  const uid = useUid();
  return useQuery({
    queryKey: ["recipes", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("recipes_generated").select("*").eq("user_id", uid!).order("created_at", { ascending: false }).limit(300)) as SavedRecipe[],
  });
}
export function useRecipe(id: string | undefined) {
  return useQuery({
    queryKey: ["recipe", id], enabled: !!id,
    queryFn: async () => unwrap(await supabase.from("recipes_generated").select("*").eq("id", id!).maybeSingle()) as SavedRecipe | null,
  });
}
export function useDeleteRecipe() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => unwrap(await supabase.from("recipes_generated").delete().eq("id", id).select()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["recipes", uid] }); qc.invalidateQueries({ queryKey: ["favorites", uid] }); toast.success("Receita excluída."); },
    onError: fail,
  });
}
export function useSetPublic() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, isPublic }: { id: string; isPublic: boolean }) =>
      unwrap(await supabase.from("recipes_generated").update({ is_public: isPublic }).eq("id", id).select().single()) as SavedRecipe,
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["recipes", uid] }); qc.invalidateQueries({ queryKey: ["recipe", r.id] });
      toast.success(r.is_public ? "Link público ativado." : "Compartilhamento desativado.");
    },
    onError: fail,
  });
}

/* ───────── Favoritos ───────── */
export function useFavorites() {
  const uid = useUid();
  return useQuery({
    queryKey: ["favorites", uid], enabled: !!uid,
    queryFn: async () => (unwrap(await supabase.from("favorites").select("recipe_id").eq("user_id", uid!)) as { recipe_id: string }[]).map((f) => f.recipe_id),
  });
}
export function useToggleFavorite() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ recipeId, on }: { recipeId: string; on: boolean }) => {
      if (on) unwrap(await supabase.from("favorites").upsert({ user_id: uid!, recipe_id: recipeId }, { onConflict: "user_id,recipe_id" }).select());
      else unwrap(await supabase.from("favorites").delete().eq("user_id", uid!).eq("recipe_id", recipeId).select());
      return on;
    },
    onSuccess: (on) => { qc.invalidateQueries({ queryKey: ["favorites", uid] }); toast.success(on ? "Adicionada aos favoritos ❤️" : "Removida dos favoritos."); },
    onError: fail,
  });
}

/* ───────── Coleções ───────── */
export function useCollections() {
  const uid = useUid();
  return useQuery({
    queryKey: ["collections", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("collections").select("*").eq("user_id", uid!).order("created_at")) as Collection[],
  });
}
export function useCollectionItems() {
  const uid = useUid();
  return useQuery({
    queryKey: ["collection_items", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("collection_items").select("collection_id,recipe_id").eq("user_id", uid!)) as { collection_id: string; recipe_id: string }[],
  });
}
export function useCreateCollection() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (name: string) => unwrap(await supabase.from("collections").insert({ user_id: uid!, name: name.trim() }).select().single()) as Collection,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["collections", uid] }); toast.success("Coleção criada."); },
    onError: fail,
  });
}
export function useDeleteCollection() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => unwrap(await supabase.from("collections").delete().eq("id", id).select()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["collections", uid] }); qc.invalidateQueries({ queryKey: ["collection_items", uid] }); toast.success("Coleção removida."); },
    onError: fail,
  });
}
export function useToggleInCollection() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ collectionId, recipeId, on }: { collectionId: string; recipeId: string; on: boolean }) => {
      if (on) unwrap(await supabase.from("collection_items").upsert({ user_id: uid!, collection_id: collectionId, recipe_id: recipeId }, { onConflict: "collection_id,recipe_id" }).select());
      else unwrap(await supabase.from("collection_items").delete().eq("collection_id", collectionId).eq("recipe_id", recipeId).select());
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["collection_items", uid] }),
    onError: fail,
  });
}

/* ───────── Lista de compras ───────── */
export function useShoppingLists() {
  const uid = useUid();
  return useQuery({
    queryKey: ["lists", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("shopping_lists").select("*").eq("user_id", uid!).order("created_at", { ascending: false })) as ShoppingList[],
  });
}
export function useCreateList() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (name: string) => unwrap(await supabase.from("shopping_lists").insert({ user_id: uid!, name: name.trim() || "Nova lista" }).select().single()) as ShoppingList,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["lists", uid] }),
    onError: fail,
  });
}
export function useUpdateList() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...patch }: Partial<ShoppingList> & { id: string }) => unwrap(await supabase.from("shopping_lists").update(patch).eq("id", id).select()),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["lists", uid] }),
    onError: fail,
  });
}
export function useShoppingItems(listId: string | null) {
  return useQuery({
    queryKey: ["items", listId], enabled: !!listId,
    queryFn: async () => unwrap(await supabase.from("shopping_items").select("*").eq("list_id", listId!).order("created_at")) as ShoppingItem[],
  });
}
export function useAddShoppingItems() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ listId, items }: { listId: string; items: { name: string; quantity?: number | null; unit?: string | null; category?: string; source_recipe_id?: string | null }[] }) => {
      unwrap(await supabase.from("shopping_items").insert(items.map((i) => ({
        user_id: uid!, list_id: listId, name: i.name.trim(), quantity: i.quantity ?? null, unit: i.unit ?? null,
        category: i.category ?? "outros", source_recipe_id: i.source_recipe_id ?? null,
      }))).select());
      return listId;
    },
    onSuccess: (listId) => qc.invalidateQueries({ queryKey: ["items", listId] }),
    onError: fail,
  });
}
export function useUpdateShoppingItem() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, listId: _l, ...patch }: Partial<ShoppingItem> & { id: string; listId: string }) =>
      unwrap(await supabase.from("shopping_items").update(patch).eq("id", id).select()),
    onSuccess: (_d, v) => qc.invalidateQueries({ queryKey: ["items", v.listId] }),
    onError: fail,
  });
}
export function useRemoveShoppingItem() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id }: { id: string; listId: string }) => unwrap(await supabase.from("shopping_items").delete().eq("id", id).select()),
    onSuccess: (_d, v) => qc.invalidateQueries({ queryKey: ["items", v.listId] }),
    onError: fail,
  });
}

/* ───────── Chat ───────── */
export function useConversations() {
  const uid = useUid();
  return useQuery({
    queryKey: ["convos", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("chat_conversations").select("*").eq("user_id", uid!).order("updated_at", { ascending: false })) as Conversation[],
  });
}
export function useMessages(conversationId: string | null) {
  return useQuery({
    queryKey: ["messages", conversationId], enabled: !!conversationId,
    queryFn: async () => unwrap(await supabase.from("chat_messages").select("*").eq("conversation_id", conversationId!).order("created_at")) as ChatMessage[],
  });
}
export function useCreateConversation() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (recipeId?: string | null) =>
      unwrap(await supabase.from("chat_conversations").insert({ user_id: uid!, recipe_id: recipeId ?? null }).select().single()) as Conversation,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["convos", uid] }),
    onError: fail,
  });
}
export function useDeleteConversation() {
  const uid = useUid(); const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => unwrap(await supabase.from("chat_conversations").delete().eq("id", id).select()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["convos", uid] }); toast.success("Conversa apagada."); },
    onError: fail,
  });
}

/* ───────── Assinatura e uso ───────── */
export function useSubscription() {
  const uid = useUid();
  return useQuery({
    queryKey: ["subscription", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("subscriptions").select("plan,status,provider,current_period_end").eq("user_id", uid!).maybeSingle()) as Subscription | null,
  });
}
/** Plano EFETIVO: só é pago quando o provedor confirmou (status = active). */
export function useEffectivePlan(): "free" | "premium" | "familia" {
  const { data } = useSubscription();
  return data && data.status === "active" ? data.plan : "free";
}
export function useUsageToday() {
  const uid = useUid();
  return useQuery({
    queryKey: ["usage", uid], enabled: !!uid,
    queryFn: async () => unwrap(await supabase.from("usage_limits").select("kind,count").eq("user_id", uid!).eq("day", new Date().toISOString().slice(0, 10))) as UsageRow[],
  });
}
