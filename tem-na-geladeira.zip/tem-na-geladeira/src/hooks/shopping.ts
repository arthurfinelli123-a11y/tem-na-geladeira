import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/store/auth";

export interface NewShoppingItem {
  name: string; quantity?: number | null; unit?: string | null; category?: string; source_recipe_id?: string | null;
}

/** Adiciona itens à lista ativa (cria "Minha lista" se não houver). Ignora o que já está pendente na lista. */
export function useAddToShopping() {
  const uid = useAuth((s) => s.user?.id);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (items: NewShoppingItem[]) => {
      if (!uid) throw new Error("não autenticado");
      let { data: list } = await supabase.from("shopping_lists").select("id").eq("user_id", uid)
        .eq("archived", false).order("created_at", { ascending: true }).limit(1).maybeSingle();
      if (!list) {
        const r = await supabase.from("shopping_lists").insert({ user_id: uid, name: "Minha lista" }).select("id").single();
        if (r.error) throw r.error;
        list = r.data;
      }
      const { data: existing } = await supabase.from("shopping_items").select("name").eq("list_id", list.id).eq("checked", false);
      const have = new Set((existing ?? []).map((e) => e.name.toLowerCase()));
      const fresh = items.filter((i) => !have.has(i.name.trim().toLowerCase()));
      if (fresh.length) {
        const { error } = await supabase.from("shopping_items").insert(fresh.map((i) => ({
          user_id: uid, list_id: list!.id, name: i.name.trim(), quantity: i.quantity ?? null, unit: i.unit ?? null,
          category: i.category ?? "outros", source_recipe_id: i.source_recipe_id ?? null,
        })));
        if (error) throw error;
      }
      return { listId: list.id, added: fresh.length, skipped: items.length - fresh.length };
    },
    onSuccess: ({ listId, added, skipped }) => {
      qc.invalidateQueries({ queryKey: ["items", listId] });
      qc.invalidateQueries({ queryKey: ["lists", uid] });
      toast.success(added ? `${added} ${added === 1 ? "item adicionado" : "itens adicionados"} à lista de compras.` : "Esses itens já estão na sua lista.",
        skipped && added ? { description: `${skipped} já estavam na lista.` } : undefined);
    },
    onError: () => toast.error("Não foi possível atualizar a lista de compras."),
  });
}
