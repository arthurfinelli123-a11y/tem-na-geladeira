import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { MODES, type ModeId } from "@/lib/modes";
import { useEffectivePlan } from "@/hooks/data";
import { cn } from "@/lib/utils";

export default function Modes() {
  const nav = useNavigate();
  const plan = useEffectivePlan();
  const locked = plan === "free";
  const [opt, setOpt] = useState<Partial<Record<ModeId, string>>>({ rapido: "20" });

  function go(id: ModeId) {
    const o = opt[id];
    nav(`/gerar?mode=${id}${o ? `&modeOption=${encodeURIComponent(o)}` : ""}`);
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl">Modos de cozinha</h1>
        <p className="text-sm text-muted">Cada modo muda o jeito como a IA cria suas receitas.</p>
      </div>
      {locked && (
        <div className="flex items-center gap-3 rounded-2xl bg-accent/15 p-3 text-sm">
          <Lock className="h-5 w-5 shrink-0 text-accent-dark" />
          <p>Os modos especiais fazem parte do plano Premium. <Link to="/planos" className="font-semibold underline">Ver planos</Link></p>
        </div>
      )}
      <ul className="space-y-3">
        {MODES.map((m) => (
          <li key={m.id} className={cn("card space-y-3", locked && "opacity-80")}>
            <div className="flex items-start gap-3">
              <span className="text-3xl" aria-hidden>{m.emoji}</span>
              <div><h2 className="text-xl">{m.label}</h2><p className="text-sm text-muted">{m.description}</p></div>
            </div>
            {m.option && (
              m.option.free ? (
                <>
                  <input className="input" list={`opts-${m.id}`} placeholder={m.option.label} maxLength={40}
                    value={opt[m.id] ?? ""} onChange={(e) => setOpt({ ...opt, [m.id]: e.target.value })} aria-label={m.option.label} />
                  <datalist id={`opts-${m.id}`}>{m.option.choices.map((c) => <option key={c} value={c} />)}</datalist>
                </>
              ) : (
                <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={m.option.label}>
                  {m.option.choices.map((c) => (
                    <button key={c} type="button" role="radio" aria-checked={opt[m.id] === c} onClick={() => setOpt({ ...opt, [m.id]: c })}
                      className={cn("tap rounded-full border px-4 text-sm font-medium", opt[m.id] === c ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand")}>
                      {c} min
                    </button>
                  ))}
                </div>
              )
            )}
            <Button full variant={locked ? "outline" : "primary"} onClick={() => (locked ? nav("/planos") : go(m.id))}>
              {locked ? <><Lock className="h-4 w-4" />Disponível no Premium</> : "Usar este modo"}
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
