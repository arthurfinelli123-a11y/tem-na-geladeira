import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Pencil, Trash2, Check, X, Ban, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { EmptyState, Spinner } from "@/components/ui/States";
import { IngredientInput } from "@/components/IngredientInput";
import { useAddPantry, usePantry, useRemovePantry, useUpdatePantry } from "@/hooks/data";
import { CATEGORIES, UNITS, categoryLabel } from "@/lib/utils";
import type { PantryItem } from "@/lib/types";

const BASICS = [
  { name: "Sal", category: "temperos" },
  { name: "Água", category: "bebidas" },
  { name: "Óleo", category: "outros" },
  { name: "Açúcar", category: "outros" },
  { name: "Pimenta-do-reino", category: "temperos" },
  { name: "Vinagre", category: "outros" },
];

export default function Pantry() {
  const { data: items = [], isLoading } = usePantry();
  const add = useAddPantry();
  const update = useUpdatePantry();
  const remove = useRemovePantry();
  const [tab, setTab] = useState<"have" | "excluded">("have");
  const [filter, setFilter] = useState<string>("todas");
  const [editing, setEditing] = useState<string | null>(null);

  const list = items.filter((i) => (tab === "have" ? !i.excluded : i.excluded));
  const grouped = useMemo(() => {
    const g = new Map<string, PantryItem[]>();
    for (const i of list) {
      if (filter !== "todas" && i.category !== filter) continue;
      g.set(i.category, [...(g.get(i.category) ?? []), i]);
    }
    return CATEGORIES.map((c) => ({ ...c, items: g.get(c.id) ?? [] })).filter((c) => c.items.length);
  }, [list, filter]);

  function addItem(name: string, category: string) {
    if (items.some((i) => i.name.toLowerCase() === name.toLowerCase() && i.excluded === (tab === "excluded"))) {
      toast.info(`“${name}” já está na lista.`); return;
    }
    add.mutate([{ name, category, excluded: tab === "excluded" }], {
      onSuccess: () => toast.success(tab === "excluded" ? `“${name}” não será usado nas receitas.` : `“${name}” adicionado à despensa.`),
    });
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl">Minha despensa</h1>
        <p className="text-sm text-muted">Tudo o que você tem em casa. A IA só usa o que está aqui.</p>
      </div>

      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-brand-soft p-1" role="tablist">
        {([["have", "Eu tenho"], ["excluded", "Não quero usar"]] as const).map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`tap rounded-xl text-sm font-semibold transition-colors ${tab === id ? "bg-white text-brand shadow-soft" : "text-muted"}`}>
            {label} ({items.filter((i) => i.excluded === (id === "excluded")).length})
          </button>
        ))}
      </div>

      <div className="card space-y-3">
        <IngredientInput onAdd={addItem} placeholder={tab === "have" ? "Adicionar ingrediente…" : "Ingrediente que você NÃO quer usar…"} />
        {tab === "excluded" && (
          <p className="flex items-center gap-2 text-xs text-muted"><Ban className="h-4 w-4" />Itens aqui nunca aparecem nas receitas geradas.</p>
        )}
      </div>

      {tab === "have" && (
        <section className="card space-y-2" aria-labelledby="basics-title">
          <h2 id="basics-title" className="text-lg">Básicos que você tem em casa</h2>
          <p className="text-xs text-muted">
            A IA nunca presume que você tem sal, óleo ou água. Marque só o que realmente tem — o modo “Não quero comprar nada” usa apenas itens confirmados.
          </p>
          <div className="flex flex-wrap gap-2">
            {BASICS.map((b) => {
              const has = items.some((i) => !i.excluded && i.name.toLowerCase() === b.name.toLowerCase());
              return (
                <button key={b.name} type="button" aria-pressed={has} disabled={has || add.isPending}
                  onClick={() => addItem(b.name, b.category)}
                  className={`tap inline-flex items-center gap-1.5 rounded-full border px-4 text-sm font-medium ${has ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand"}`}>
                  {has && <Check className="h-4 w-4" />}{b.name}
                </button>
              );
            })}
          </div>
        </section>
      )}

      <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1" aria-label="Filtrar por categoria">
        {[{ id: "todas", label: "Todas", emoji: "✨" }, ...CATEGORIES].map((c) => (
          <button key={c.id} onClick={() => setFilter(c.id)}
            className={`tap shrink-0 whitespace-nowrap rounded-full border px-4 text-sm font-medium ${filter === c.id ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand"}`}>
            {c.emoji} {c.label}
          </button>
        ))}
      </div>

      {isLoading ? <Spinner /> : grouped.length === 0 ? (
        <EmptyState variant="pantry"
          title={tab === "have" ? "Sua despensa está vazia" : "Nada excluído por enquanto"}
          text={tab === "have" ? "Digite o que você tem em casa ou envie uma foto da geladeira." : "Adicione ingredientes que você não gosta ou não pode usar."}
          action={tab === "have" ? <Link to="/foto"><Button variant="outline">Reconhecer por foto</Button></Link> : undefined} />
      ) : (
        grouped.map((g) => (
          <section key={g.id} aria-label={g.label}>
            <h2 className="mb-2 text-lg">{g.emoji} {g.label}</h2>
            <ul className="space-y-2">
              {g.items.map((i) => (
                <li key={i.id} className="card !p-3">
                  {editing === i.id ? (
                    <EditRow item={i} onCancel={() => setEditing(null)}
                      onSave={(patch) => update.mutate({ id: i.id, ...patch }, { onSuccess: () => { setEditing(null); toast.success("Item atualizado."); } })} />
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium">{i.name}</p>
                        <p className="text-xs text-muted">{i.quantity ? `${i.quantity} ${i.unit ?? ""}`.trim() : "Sem quantidade"} · {categoryLabel(i.category)}</p>
                      </div>
                      <button className="tap grid place-items-center rounded-xl text-brand hover:bg-brand-soft" onClick={() => setEditing(i.id)} aria-label={`Editar ${i.name}`}><Pencil className="h-4 w-4" /></button>
                      <button className="tap grid place-items-center rounded-xl text-danger hover:bg-danger/5" aria-label={`Remover ${i.name}`}
                        onClick={() => remove.mutate(i.id, { onSuccess: () => toast.success(`“${i.name}” removido.`) })}><Trash2 className="h-4 w-4" /></button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </section>
        ))
      )}

      {tab === "have" && items.some((i) => !i.excluded) && (
        <Link to="/gerar" className="sticky bottom-24 block md:bottom-4">
          <Button variant="cta" full className="shadow-lift"><Sparkles className="h-5 w-5" />Gerar receitas com a despensa</Button>
        </Link>
      )}
    </div>
  );
}

function EditRow({ item, onSave, onCancel }: {
  item: PantryItem; onSave: (p: Partial<PantryItem>) => void; onCancel: () => void;
}) {
  const [name, setName] = useState(item.name);
  const [qty, setQty] = useState(item.quantity?.toString() ?? "");
  const [unit, setUnit] = useState(item.unit ?? "un");
  const [cat, setCat] = useState(item.category);
  const q = qty.replace(",", ".");
  const invalid = !name.trim() || (q !== "" && (isNaN(Number(q)) || Number(q) < 0));

  return (
    <div className="space-y-2">
      <input className="input" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} aria-label="Nome" />
      <div className="grid grid-cols-2 gap-2">
        <input className="input" inputMode="decimal" placeholder="Quantidade" value={qty} onChange={(e) => setQty(e.target.value)} aria-label="Quantidade" />
        <select className="input" value={unit} onChange={(e) => setUnit(e.target.value)} aria-label="Unidade">
          {UNITS.map((u) => <option key={u}>{u}</option>)}
        </select>
      </div>
      <select className="input" value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Categoria">
        {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
      </select>
      <div className="flex gap-2">
        <Button className="flex-1" disabled={invalid} onClick={() => onSave({ name: name.trim(), category: cat, quantity: q === "" ? null : Number(q), unit: q === "" ? null : unit })}><Check className="h-4 w-4" />Salvar</Button>
        <Button variant="outline" className="flex-1" onClick={onCancel}><X className="h-4 w-4" />Cancelar</Button>
      </div>
    </div>
  );
}
