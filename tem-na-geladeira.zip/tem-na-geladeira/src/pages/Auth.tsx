import { useState, type ReactNode } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { ErrorBox, NotConfigured } from "@/components/ui/States";
import { Logo } from "@/components/ui/Logo";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { useAuth } from "@/store/auth";

function Frame({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-md space-y-5 py-4">
      <div className="text-center">
        <div className="mb-3 flex justify-center"><Logo size={52} /></div>
        <h1 className="text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {!isSupabaseConfigured && (
        <NotConfigured what="Supabase" how="Crie o arquivo .env com VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY (veja o README)." />
      )}
      <div className="card space-y-4">{children}</div>
    </div>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {error && <p className="mt-1 text-sm text-danger" role="alert">{error}</p>}
    </div>
  );
}

function friendlyAuthError(msg: string) {
  const m = msg.toLowerCase();
  if (m.includes("invalid login")) return "E-mail ou senha incorretos.";
  if (m.includes("already registered") || m.includes("already been registered")) return "Este e-mail já tem uma conta. Tente entrar.";
  if (m.includes("email not confirmed")) return "Confirme seu e-mail pelo link que enviamos antes de entrar.";
  if (m.includes("rate limit") || m.includes("too many")) return "Muitas tentativas. Aguarde um pouco e tente de novo.";
  if (m.includes("password")) return "A senha não atende aos requisitos (mínimo de 8 caracteres).";
  if (m.includes("fetch") || m.includes("network")) return "Sem conexão com o servidor. Verifique sua internet.";
  return "Não foi possível concluir. Tente novamente.";
}

const GOOGLE = import.meta.env.VITE_ENABLE_GOOGLE_AUTH === "true";

async function googleLogin() {
  const { error } = await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${window.location.origin}/painel` } });
  if (error) toast.error(friendlyAuthError(error.message));
}

function GoogleButton() {
  if (!GOOGLE) return null;
  return (
    <>
      <div className="flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-brand/10" />ou<span className="h-px flex-1 bg-brand/10" /></div>
      <Button type="button" variant="outline" full onClick={googleLogin}>Continuar com Google</Button>
    </>
  );
}

/* ─────────── Login ─────────── */
const loginSchema = z.object({ email: z.string().email("Digite um e-mail válido."), password: z.string().min(1, "Digite sua senha.") });

export function Login() {
  const user = useAuth((s) => s.user);
  const nav = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from ?? "/painel";
  const [err, setErr] = useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof loginSchema>>({ resolver: zodResolver(loginSchema) });

  if (user) return <Navigate to={from} replace />;

  async function onSubmit(v: z.infer<typeof loginSchema>) {
    setErr(null);
    const { error } = await supabase.auth.signInWithPassword(v);
    if (error) { setErr(friendlyAuthError(error.message)); return; }
    toast.success("Bem-vindo de volta! 👋");
    nav(from, { replace: true });
  }

  return (
    <Frame title="Entrar" subtitle="Sua cozinha está esperando.">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
        <Field label="E-mail" error={errors.email?.message}>
          <input className="input" type="email" autoComplete="email" inputMode="email" placeholder="voce@email.com" {...register("email")} />
        </Field>
        <Field label="Senha" error={errors.password?.message}>
          <input className="input" type="password" autoComplete="current-password" {...register("password")} />
        </Field>
        {err && <ErrorBox message={err} />}
        <Button type="submit" full loading={isSubmitting} disabled={!isSupabaseConfigured}>Entrar</Button>
        <GoogleButton />
      </form>
      <div className="flex justify-between text-sm">
        <Link to="/recuperar-senha" className="tap flex items-center font-medium text-brand underline">Esqueci a senha</Link>
        <Link to="/cadastro" className="tap flex items-center font-medium text-brand underline">Criar conta</Link>
      </div>
    </Frame>
  );
}

/* ─────────── Cadastro ─────────── */
const signupSchema = z.object({
  name: z.string().trim().min(2, "Digite seu nome."),
  email: z.string().email("Digite um e-mail válido."),
  password: z.string().min(8, "Use ao menos 8 caracteres."),
  terms: z.literal(true, { errorMap: () => ({ message: "É preciso aceitar os termos para criar a conta." }) }),
});

export function Signup() {
  const user = useAuth((s) => s.user);
  const nav = useNavigate();
  const [err, setErr] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof signupSchema>>({ resolver: zodResolver(signupSchema) });

  if (user) return <Navigate to="/painel" replace />;

  async function onSubmit(v: z.infer<typeof signupSchema>) {
    setErr(null);
    const { data, error } = await supabase.auth.signUp({
      email: v.email, password: v.password,
      options: { data: { full_name: v.name }, emailRedirectTo: `${window.location.origin}/painel` },
    });
    if (error) { setErr(friendlyAuthError(error.message)); return; }
    if (data.session) { toast.success("Conta criada! Vamos cozinhar 🍳"); nav("/painel", { replace: true }); }
    else setSent(true); // projeto exige confirmação por e-mail
  }

  if (sent) {
    return (
      <Frame title="Confirme seu e-mail" subtitle="Quase lá!">
        <p className="text-sm text-muted">Enviamos um link de confirmação para o seu e-mail. Clique nele e depois entre na sua conta.</p>
        <Link to="/login"><Button full>Ir para o login</Button></Link>
      </Frame>
    );
  }

  return (
    <Frame title="Criar conta grátis" subtitle="Receitas com o que você já tem em casa.">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
        <Field label="Nome" error={errors.name?.message}><input className="input" autoComplete="name" {...register("name")} /></Field>
        <Field label="E-mail" error={errors.email?.message}>
          <input className="input" type="email" autoComplete="email" inputMode="email" {...register("email")} />
        </Field>
        <Field label="Senha" error={errors.password?.message}>
          <input className="input" type="password" autoComplete="new-password" {...register("password")} />
        </Field>
        <div>
          <label className="flex min-h-[44px] items-start gap-3 text-sm text-ink">
            <input type="checkbox" className="mt-1 h-5 w-5 accent-[#1F4E3D]" {...register("terms")} />
            <span>Li e aceito os <Link to="/termos" className="underline">Termos de uso</Link> e a <Link to="/privacidade" className="underline">Política de privacidade</Link>.</span>
          </label>
          {errors.terms && <p className="text-sm text-danger" role="alert">{errors.terms.message}</p>}
        </div>
        {err && <ErrorBox message={err} />}
        <Button type="submit" variant="cta" full loading={isSubmitting} disabled={!isSupabaseConfigured}>Criar conta</Button>
        <GoogleButton />
      </form>
      <p className="text-center text-sm">Já tem conta? <Link to="/login" className="font-semibold text-brand underline">Entrar</Link></p>
    </Frame>
  );
}

/* ─────────── Recuperação de senha ─────────── */
const emailSchema = z.object({ email: z.string().email("Digite um e-mail válido.") });

export function Forgot() {
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof emailSchema>>({ resolver: zodResolver(emailSchema) });

  async function onSubmit(v: z.infer<typeof emailSchema>) {
    setErr(null);
    const { error } = await supabase.auth.resetPasswordForEmail(v.email, { redirectTo: `${window.location.origin}/redefinir-senha` });
    if (error) { setErr(friendlyAuthError(error.message)); return; }
    setDone(true);
    toast.success("Se o e-mail existir, enviamos o link.");
  }

  return (
    <Frame title="Recuperar senha" subtitle="Enviaremos um link para você criar uma nova senha.">
      {done ? (
        <p className="text-sm text-muted">Se esse e-mail tiver uma conta, você receberá o link em instantes. Confira também o spam.</p>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <Field label="E-mail" error={errors.email?.message}><input className="input" type="email" inputMode="email" {...register("email")} /></Field>
          {err && <ErrorBox message={err} />}
          <Button type="submit" full loading={isSubmitting} disabled={!isSupabaseConfigured}>Enviar link</Button>
        </form>
      )}
      <Link to="/login" className="tap flex items-center justify-center text-sm font-medium text-brand underline">Voltar ao login</Link>
    </Frame>
  );
}

/* ─────────── Redefinir senha (chegada pelo link do e-mail) ─────────── */
const resetSchema = z.object({ password: z.string().min(8, "Use ao menos 8 caracteres.") });

export function Reset() {
  const nav = useNavigate();
  const [err, setErr] = useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof resetSchema>>({ resolver: zodResolver(resetSchema) });

  async function onSubmit(v: z.infer<typeof resetSchema>) {
    setErr(null);
    const { error } = await supabase.auth.updateUser({ password: v.password });
    if (error) { setErr(friendlyAuthError(error.message)); return; }
    toast.success("Senha atualizada!");
    nav("/painel", { replace: true });
  }

  return (
    <Frame title="Nova senha">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
        <Field label="Nova senha" error={errors.password?.message}>
          <input className="input" type="password" autoComplete="new-password" {...register("password")} />
        </Field>
        {err && <ErrorBox message={err} />}
        <Button type="submit" full loading={isSubmitting}>Salvar nova senha</Button>
      </form>
    </Frame>
  );
}
