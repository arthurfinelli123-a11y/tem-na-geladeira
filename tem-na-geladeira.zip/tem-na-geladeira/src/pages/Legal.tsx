const CONTACT = (import.meta.env.VITE_SUPPORT_EMAIL as string | undefined) || null;

export default function Legal({ kind }: { kind: "privacy" | "terms" }) {
  return kind === "privacy" ? <Privacy /> : <Terms />;
}

function Wrap({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="mx-auto max-w-2xl space-y-4 pb-6 text-sm leading-relaxed [&_h2]:mt-4 [&_h2]:text-xl [&_ul]:list-disc [&_ul]:pl-5">
      <h1 className="text-3xl">{title}</h1>
      <p className="rounded-2xl bg-accent/15 p-3 text-xs">Modelo inicial. Revise este texto com um profissional jurídico e complete os dados da empresa antes de publicar.</p>
      {children}
    </article>
  );
}

function Privacy() {
  return (
    <Wrap title="Política de privacidade">
      <p>Explicamos quais dados o Tem na Geladeira usa e por quê, em linha com a LGPD.</p>
      <h2>Dados que tratamos</h2>
      <ul>
        <li>Conta: e-mail, nome e foto (opcionais).</li>
        <li>Conteúdo que você cria: despensa, preferências, alergias, receitas, listas, planos e conversas com o Chef IA.</li>
        <li>Uso: contadores diários para aplicar os limites do plano.</li>
      </ul>
      <h2>Como usamos</h2>
      <ul>
        <li>Para oferecer o serviço: gerar receitas, planos e respostas do Chef IA.</li>
        <li>Para usar seus dados com a IA pedimos sua <b>permissão explícita</b>, que você pode revogar em Configurações.</li>
        <li>Seus dados são isolados por conta (segurança em nível de linha no banco). Outras pessoas só veem uma receita se você ativar o link público.</li>
      </ul>
      <h2>IA e terceiros</h2>
      <p>Ao usar recursos de IA, trechos relevantes (ingredientes, preferências, restrições, mensagens e, no reconhecimento por foto, a imagem enviada) são enviados ao provedor de IA configurado pelo serviço apenas para gerar a resposta. As fotos não são armazenadas por nós.</p>
      <h2>Seus direitos</h2>
      <p>Você pode acessar, corrigir, exportar (Configurações → Exportar meus dados) e solicitar a exclusão dos seus dados.</p>
      <h2>Contato</h2>
      <p>{CONTACT ? <>Escreva para <a className="underline" href={`mailto:${CONTACT}`}>{CONTACT}</a>.</> : "Defina VITE_SUPPORT_EMAIL no .env para exibir o contato de suporte aqui."}</p>
    </Wrap>
  );
}

function Terms() {
  return (
    <Wrap title="Termos de uso">
      <h2>O serviço</h2>
      <p>O Tem na Geladeira usa inteligência artificial para sugerir receitas a partir dos ingredientes que você informa.</p>
      <h2>Segurança alimentar</h2>
      <ul>
        <li>As receitas são sugestões geradas por IA e podem conter erros. Confira ingredientes, alergias, rótulos e validade antes de preparar.</li>
        <li>Nunca consuma alimento estragado ou com aspecto/cheiro duvidoso. Na dúvida, descarte.</li>
        <li>A identificação de ingredientes por foto é apenas uma sugestão e não confirma que o alimento está próprio para consumo.</li>
        <li>Informações nutricionais, quando exibidas, são aproximadas e não substituem orientação de profissional de saúde.</li>
      </ul>
      <h2>Planos e pagamentos</h2>
      <p>Recursos Premium e Família dependem de assinatura confirmada pelo provedor de pagamento. Limites diários podem se aplicar a cada plano.</p>
      <h2>Responsabilidades</h2>
      <p>Você é responsável pelas informações que fornece e pelo uso das receitas. Não use o serviço para fins ilegais ou para tentar burlar limites e proteções.</p>
    </Wrap>
  );
}
