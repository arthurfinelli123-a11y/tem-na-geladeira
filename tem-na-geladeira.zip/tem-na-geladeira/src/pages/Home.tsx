import { useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { X, Sparkles, ListChecks, ChefHat, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { IngredientInput } from "@/components/IngredientInput";
import { useAuth } from "@/store/auth";
import { useDraft } from "@/store/draft";
import { useAddPantry, usePantry, useRemovePantry } from "@/hooks/data";
import { PLAN_INFO, PRICES } from "@/lib/plans";

const POPULAR = [
  { label: "Café da manhã", emoji: "🥐", mealType: "cafe" },
  { label: "Almoço", emoji: "🍛", mealType: "almoco" },
  { label: "Jantar", emoji: "🍝", mealType: "jantar" },
  { label: "Lanches", emoji: "🥪", mealType: "lanche" },
  { label: "Sobremesas", emoji: "🍰", mealType: "sobremesa" },
  { label: "Rápidas", emoji: "⚡", mealType: "qualquer", maxMinutes: 20 },
];

// Inspirações de pratos clássicos (NÃO são resultados da IA): servem de atalho para preencher ingredientes.
const INSPIRATIONS = [
  { title: "Omelete de queijo", emoji: "🍳", items: ["Ovo", "Queijo mussarela", "Sal"] },
  { title: "Arroz com legumes", emoji: "🍚", items: ["Arroz", "Cenoura", "Cebola", "Alho"] },
  { title: "Panqueca simples", emoji: "🥞", items: ["Farinha de trigo", "Leite", "Ovo"] },
  { title: "Macarrão alho e óleo", emoji: "🍝", items: ["Macarrão espaguete", "Alho", "Azeite"] },
];

const STEPS = [
  { icon: ListChecks, title: "Diga o que tem", text: "Digite os ingredientes ou envie uma foto da geladeira." },
  { icon: ChefHat, title: "Escolha seu estilo", text: "Tempo, dificuldade, porções, restrições e modos especiais." },
  { icon: Sparkles, title: "Receba receitas", text: "A IA cria receitas com quantidades, passos e substituições." },
];

export default function Home() {
  const user = useAuth((s) => s.user);
  const nav = useNavigate();
  const { hash } = useLocation();
  const { guestIngredients, addGuest, removeGuest } = useDraft();
  const { data: pantry = [] } = usePantry();
  const addPantry = useAddPantry();
  const removePantry = useRemovePantry();

  useEffect(() => {
    if (hash) document.querySelector(hash)?.scrollIntoView({ behavior: "smooth" });
  }, [hash]);

  // Logado: os chips refletem a despensa real. Visitante: rascunho local.
  const chips = user ? pantry.filter((p) => !p.excluded).map((p) => p.name) : guestIngredients;

  function add(name: string, category: string) {
    if (user) addPantry.mutate([{ name, category }]);
    else addGuest(name);
  }
  function remove(name: string) {
    if (user) {
      const item = pantry.find((p) => p.name === name && !p.excluded);
      if (item) removePantry.mutate(item.id);
    } else removeGuest(name);
  }
  function generate() {
    if (chips.length === 0) { toast.info("Adicione ao menos um ingrediente para começar."); return; }
    nav(user ? "/gerar" : "/cadastro");
    if (!user) toast.info("Crie sua conta grátis para gerar receitas. Seus ingredientes ficam salvos.");
  }
  function applyInspiration(items: string[]) {
    items.forEach((i) => add(i, "outros"));
    toast.success("Ingredientes adicionados!");
  }

  return (
    <div className="space-y-12 pb-6">
      {/* Hero */}
      <section className="pt-2 text-center">
        <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-xl text-4xl leading-tight sm:text-5xl">
          O que vamos cozinhar hoje?
        </motion.h1>
        <p className="mx-auto mt-3 max-w-md text-base text-muted">
          Descubra receitas incríveis usando os ingredientes que você já tem em casa.
        </p>

        <div className="card mx-auto mt-6 max-w-xl space-y-3 text-left">
          <IngredientInput onAdd={add} />
          {chips.length > 0 && (
            <ul className="flex flex-wrap gap-2" aria-label="Ingredientes adicionados">
              {chips.map((c) => (
                <li key={c} className="chip">
                  {c}
                  <button onClick={() => remove(c)} aria-label={`Remover ${c}`} className="grid h-6 w-6 place-items-center rounded-full hover:bg-white"><X className="h-3.5 w-3.5" /></button>
                </li>
              ))}
            </ul>
          )}
          <Button variant="cta" full onClick={generate}><Sparkles className="h-5 w-5" />Gerar receitas com IA</Button>
        </div>
        <p className="mt-4 text-sm italic text-brand">Sua cozinha tem os ingredientes. Nossa IA tem as ideias.</p>
      </section>

      {/* Categorias populares */}
      <section aria-labelledby="cats">
        <h2 id="cats" className="mb-3 text-2xl">Categorias populares</h2>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
          {POPULAR.map((c) => (
            <Link key={c.label} to={`/gerar?mealType=${c.mealType}${c.maxMinutes ? `&maxMinutes=${c.maxMinutes}` : ""}`}
              className="card tap flex flex-col items-center gap-1 !p-3 text-center transition-transform duration-200 hover:-translate-y-0.5">
              <span className="text-3xl" aria-hidden>{c.emoji}</span>
              <span className="text-xs font-semibold text-brand">{c.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Inspirações */}
      <section aria-labelledby="insp">
        <h2 id="insp" className="text-2xl">Inspirações para começar</h2>
        <p className="mb-3 text-sm text-muted">Pratos clássicos para você testar. A IA cria a receita final com o que você realmente tem.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {INSPIRATIONS.map((r) => (
            <div key={r.title} className="card flex items-center gap-3">
              <span className="text-4xl" aria-hidden>{r.emoji}</span>
              <div className="min-w-0 flex-1">
                <p className="font-display text-lg text-brand">{r.title}</p>
                <p className="truncate text-xs text-muted">{r.items.join(" · ")}</p>
              </div>
              <Button variant="outline" className="!min-h-[40px] px-3 text-sm" onClick={() => applyInspiration(r.items)}>Usar</Button>
            </div>
          ))}
        </div>
      </section>

      {/* Como funciona */}
      <section id="como-funciona" aria-labelledby="how">
        <h2 id="how" className="mb-3 text-2xl">Como funciona</h2>
        <ol className="grid gap-3 sm:grid-cols-3">
          {STEPS.map((s, i) => (
            <li key={s.title} className="card flex gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-brand text-white"><s.icon className="h-5 w-5" /></span>
              <div>
                <p className="font-display text-lg text-brand">{i + 1}. {s.title}</p>
                <p className="text-sm text-muted">{s.text}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* Planos */}
      <section aria-labelledby="plans">
        <h2 id="plans" className="mb-3 text-2xl">Planos</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          {PLAN_INFO.map((p) => (
            <div key={p.id} className={`card space-y-2 ${p.id === "premium" ? "ring-2 ring-accent" : ""}`}>
              <p className="font-display text-xl text-brand">{p.name}</p>
              <p className="text-sm text-muted">{p.tagline}</p>
              <p className="text-lg font-semibold">{PRICES[p.id] ?? "Em breve"}</p>
              <ul className="space-y-1 text-sm">
                {p.features.slice(0, 4).map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-brand" />{f}</li>)}
              </ul>
            </div>
          ))}
        </div>
        <Link to="/planos" className="mt-3 block"><Button variant="outline" full>Comparar planos</Button></Link>
      </section>
    </div>
  );
}
