import { Link } from "react-router-dom";
import { Check, Minus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { NotConfigured } from "@/components/ui/States";
import { CHECKOUT_URL, COMPARISON, PLAN_INFO, PRICES, type PlanId } from "@/lib/plans";
import { useEffectivePlan, useSubscription } from "@/hooks/data";
import { useAuth } from "@/store/auth";
import { cn } from "@/lib/utils";

function Cell({ v }: { v: string | boolean }) {
  if (v === true) return <Check className="mx-auto h-5 w-5 text-brand" aria-label="Incluído" />;
  if (v === false) return <Minus className="mx-auto h-5 w-5 text-muted/50" aria-label="Não incluído" />;
  return <span className="text-xs">{v}</span>;
}

export default function Plans() {
  const user = useAuth((s) => s.user);
  const current = useEffectivePlan();
  const { data: sub } = useSubscription();

  function subscribe(id: Exclude<PlanId, "free">) {
    const url = CHECKOUT_URL[id];
    if (!url) return;
    // O provedor devolve a confirmação via webhook; só então a assinatura passa a constar como ativa.
    const u = new URL(url);
    if (user) u.searchParams.set("client_reference_id", user.id);
    window.location.href = u.toString();
  }

  return (
    <div className="space-y-5">
      <div className="text-center"><h1 className="text-3xl">Escolha seu plano</h1>
        <p className="text-sm text-muted">Comece grátis e evolua quando quiser.</p></div>

      {sub?.status && sub.status !== "active" && sub.status !== "inactive" && (
        <div className="rounded-2xl bg-accent/15 p-3 text-sm">Sua assinatura está <b>{sub.status === "past_due" ? "com pagamento pendente" : "cancelada"}</b>. O plano Free está em uso até o provedor confirmar o pagamento.</div>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        {PLAN_INFO.map((p) => {
          const isCurrent = current === p.id;
          const checkout = p.id === "free" ? null : CHECKOUT_URL[p.id];
          return (
            <div key={p.id} className={cn("card flex flex-col space-y-3", p.id === "premium" && "ring-2 ring-accent")}>
              {p.id === "premium" && <span className="w-fit rounded-full bg-accent px-3 py-0.5 text-xs font-bold text-ink">Mais completo</span>}
              <div><h2 className="text-2xl">{p.name}</h2><p className="text-sm text-muted">{p.tagline}</p></div>
              <p className="font-display text-2xl text-brand">{PRICES[p.id] ?? "Em breve"}</p>
              <ul className="flex-1 space-y-1.5 text-sm">{p.features.map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-brand" />{f}</li>)}</ul>
              {p.id === "free" ? (
                isCurrent ? <Button variant="outline" full disabled>Seu plano atual</Button> :
                  <Link to={user ? "/painel" : "/cadastro"}><Button variant="outline" full>{user ? "Ir para o painel" : "Criar conta grátis"}</Button></Link>
              ) : isCurrent ? (
                <Button variant="outline" full disabled>Seu plano atual</Button>
              ) : !user ? (
                <Link to="/cadastro"><Button variant="cta" full>Criar conta para assinar</Button></Link>
              ) : checkout ? (
                <Button variant="cta" full onClick={() => subscribe(p.id as Exclude<PlanId, "free">)}>Assinar {p.name}</Button>
              ) : (
                <Button variant="outline" full disabled>Assinatura em breve</Button>
              )}
            </div>
          );
        })}
      </div>

      {(!CHECKOUT_URL.premium || !CHECKOUT_URL.familia) && (
        <NotConfigured what="Gateway de pagamento" how="Defina VITE_CHECKOUT_URL_PREMIUM / VITE_CHECKOUT_URL_FAMILIA e configure o webhook (supabase/functions/payments-webhook). Veja o README. Nenhum pagamento é simulado." />
      )}

      <section aria-label="Comparação de planos" className="card overflow-x-auto !p-2">
        <table className="w-full min-w-[420px] text-sm">
          <thead><tr className="text-left text-brand"><th className="p-2 font-semibold">Recurso</th>
            <th className="p-2 text-center">Free</th><th className="p-2 text-center">Premium</th><th className="p-2 text-center">Família</th></tr></thead>
          <tbody>{COMPARISON.map((row) => (
            <tr key={row.label} className="border-t border-brand/10">
              <td className="p-2">{row.label}</td>
              <td className="p-2 text-center"><Cell v={row.free} /></td><td className="p-2 text-center"><Cell v={row.premium} /></td><td className="p-2 text-center"><Cell v={row.familia} /></td>
            </tr>))}</tbody>
        </table>
      </section>
      <p className="text-center text-xs text-muted">O plano só é ativado depois da confirmação do pagamento pelo provedor.</p>
    </div>
  );
}
