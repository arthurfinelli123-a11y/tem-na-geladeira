import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Camera, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { Spinner } from "@/components/ui/States";
import { useEffectivePlan, useProfile, useRecipes, useSaveProfile, useSubscription } from "@/hooks/data";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/store/auth";
import { DIETS, EQUIPMENT } from "@/lib/modes";
import { cn } from "@/lib/utils";

const schema = z.object({
  full_name: z.string().trim().max(80).optional(),
  default_servings: z.number().int().min(1).max(20),
  diet_preferences: z.array(z.string()),
  allergies: z.array(z.string()),
  favorite_ingredients: z.array(z.string()),
  disliked_ingredients: z.array(z.string()),
  equipment: z.array(z.string()),
});
type Form = z.infer<typeof schema>;

function TagInput({ value, onChange, placeholder }: { value: string[]; onChange: (v: string[]) => void; placeholder: string }) {
  const [text, setText] = useState("");
  function commit() {
    const t = text.trim();
    if (t && !value.some((v) => v.toLowerCase() === t.toLowerCase())) onChange([...value, t]);
    setText("");
  }
  return (
    <div className="space-y-2">
      <input className="input" value={text} maxLength={40} placeholder={placeholder} onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); commit(); } }} onBlur={commit} />
      {value.length > 0 && (
        <ul className="flex flex-wrap gap-2">
          {value.map((v) => (
            <li key={v} className="chip">{v}
              <button type="button" aria-label={`Remover ${v}`} className="grid h-6 w-6 place-items-center rounded-full hover:bg-white" onClick={() => onChange(value.filter((x) => x !== v))}><X className="h-3.5 w-3.5" /></button></li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function Profile() {
  const user = useAuth((s) => s.user)!;
  const { data: profile, isLoading } = useProfile();
  const { data: recipes = [] } = useRecipes();
  const { data: sub } = useSubscription();
  const plan = useEffectivePlan();
  const save = useSaveProfile();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const { control, register, handleSubmit, reset, formState: { isDirty } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { default_servings: 2, diet_preferences: [], allergies: [], favorite_ingredients: [], disliked_ingredients: [], equipment: [] },
  });

  useEffect(() => {
    if (profile) reset({
      full_name: profile.full_name ?? "", default_servings: profile.default_servings, diet_preferences: profile.diet_preferences,
      allergies: profile.allergies, favorite_ingredients: profile.favorite_ingredients, disliked_ingredients: profile.disliked_ingredients, equipment: profile.equipment,
    });
  }, [profile, reset]);

  async function uploadAvatar(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 3_000_000) { toast.error("Escolha uma imagem de até 3 MB."); return; }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true, contentType: file.type });
      if (error) throw error;
      const { data } = supabase.storage.from("avatars").getPublicUrl(path);
      await save.mutateAsync({ avatar_url: data.publicUrl });
    } catch { toast.error("Não foi possível enviar a foto."); }
    finally { setUploading(false); }
  }

  if (isLoading) return <Spinner />;
  const name = profile?.full_name || user.email || "Você";

  return (
    <form onSubmit={handleSubmit((v) => save.mutate({ ...v, full_name: v.full_name || null }, { onSuccess: () => reset(v) }))} className="space-y-4">
      <h1 className="text-3xl">Meu perfil</h1>

      <div className="card flex items-center gap-4">
        <div className="relative">
          {profile?.avatar_url ? <img src={profile.avatar_url} alt="Sua foto" className="h-20 w-20 rounded-full object-cover" /> :
            <div className="grid h-20 w-20 place-items-center rounded-full bg-brand text-3xl font-bold text-white">{name[0]?.toUpperCase()}</div>}
          <button type="button" onClick={() => fileRef.current?.click()} aria-label="Trocar foto" disabled={uploading}
            className="tap absolute -bottom-1 -right-1 grid h-9 w-9 place-items-center !min-h-0 !min-w-0 rounded-full bg-accent text-ink shadow-soft"><Camera className="h-4 w-4" /></button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => uploadAvatar(e.target.files?.[0])} />
        </div>
        <div className="min-w-0"><p className="truncate font-display text-xl text-brand">{name}</p><p className="truncate text-sm text-muted">{user.email}</p>
          <Link to="/planos" className="text-sm font-semibold text-brand underline">Plano {plan === "free" ? "Free" : plan === "premium" ? "Premium" : "Família"}</Link></div>
      </div>

      <div className="card space-y-4">
        <div><label className="label" htmlFor="name">Nome</label><input id="name" className="input" {...register("full_name")} /></div>
        <div><label className="label" htmlFor="serv">Porções habituais</label>
          <Controller control={control} name="default_servings" render={({ field }) => (
            <input id="serv" type="number" min={1} max={20} inputMode="numeric" className="input" value={field.value}
              onChange={(e) => field.onChange(Math.max(1, Math.min(20, Number(e.target.value) || 1)))} />)} /></div>
        <div><span className="label">Preferências alimentares</span>
          <Controller control={control} name="diet_preferences" render={({ field }) => (
            <div className="flex flex-wrap gap-2">{DIETS.map((d) => { const on = field.value.includes(d);
              return <button type="button" key={d} aria-pressed={on} onClick={() => field.onChange(on ? field.value.filter((x) => x !== d) : [...field.value, d])}
                className={cn("tap rounded-full border px-3 text-sm", on ? "border-brand bg-brand-soft font-semibold text-brand" : "border-brand/20 bg-white text-muted")}>{d}</button>; })}</div>)} /></div>
        <div><span className="label">Alergias e restrições</span>
          <Controller control={control} name="allergies" render={({ field }) => <TagInput value={field.value} onChange={field.onChange} placeholder="Ex.: amendoim, camarão, leite — Enter para adicionar" />} />
          <p className="mt-1 text-xs text-muted">Receitas com estes itens são descartadas e você recebe um alerta destacado. Confira sempre os rótulos.</p></div>
        <div><span className="label">Ingredientes favoritos</span>
          <Controller control={control} name="favorite_ingredients" render={({ field }) => <TagInput value={field.value} onChange={field.onChange} placeholder="Ex.: queijo, manjericão" />} /></div>
        <div><span className="label">Ingredientes que não gosto</span>
          <Controller control={control} name="disliked_ingredients" render={({ field }) => <TagInput value={field.value} onChange={field.onChange} placeholder="Ex.: coentro, berinjela" />} /></div>
        <div><span className="label">Equipamentos</span>
          <Controller control={control} name="equipment" render={({ field }) => (
            <div className="flex flex-wrap gap-2">{EQUIPMENT.map((d) => { const on = field.value.includes(d);
              return <button type="button" key={d} aria-pressed={on} onClick={() => field.onChange(on ? field.value.filter((x) => x !== d) : [...field.value, d])}
                className={cn("tap rounded-full border px-3 text-sm", on ? "border-brand bg-brand-soft font-semibold text-brand" : "border-brand/20 bg-white text-muted")}>{d}</button>; })}</div>)} /></div>
        <Button type="submit" full loading={save.isPending} disabled={!isDirty}>Salvar perfil</Button>
      </div>

      <div className="card space-y-1 text-sm">
        <h2 className="text-xl">Assinatura</h2>
        <p>Plano atual: <b>{plan === "free" ? "Free" : plan === "premium" ? "Premium" : "Família"}</b></p>
        <p className="text-muted">{sub?.status === "active" ? `Ativa${sub.current_period_end ? ` até ${new Date(sub.current_period_end).toLocaleDateString("pt-BR")}` : ""}.` : "Nenhuma assinatura paga confirmada."}</p>
        <Link to="/planos" className="font-semibold text-brand underline">Gerenciar plano</Link>
      </div>
      <div className="card text-sm"><h2 className="text-xl">Histórico</h2>
        <p className="text-muted">{recipes.length} receitas geradas. <Link to="/minhas-receitas" className="font-semibold text-brand underline">Ver todas</Link></p></div>
    </form>
  );
}
