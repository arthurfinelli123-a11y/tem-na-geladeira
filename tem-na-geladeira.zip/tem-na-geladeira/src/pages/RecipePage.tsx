import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  Clock, Flame, ChefHat, Users, Heart, ShoppingCart, FolderPlus, Share2, MessageCircle, Trash2,
  AlertTriangle, ShieldAlert, Lightbulb, Shuffle, Minus, Plus, Copy,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { ErrorBox, Spinner, SafetyNotice } from "@/components/ui/States";
import { CompatBadge, DIFFICULTY, RecipeArt } from "@/components/RecipeCard";
import {
  useCollectionItems, useCollections, useCreateConversation, useDeleteRecipe, useFavorites, useRecipe,
  useSetPublic, useToggleFavorite, useToggleInCollection,
} from "@/hooks/data";
import { useAddToShopping } from "@/hooks/shopping";
import { useAuth } from "@/store/auth";
import { useEffectivePlan } from "@/hooks/data";
import type { RecipeIngredient } from "@/lib/schemas";
import { cn } from "@/lib/utils";

function fmt(n: number) {
  const r = Math.round(n * 100) / 100;
  return String(r).replace(".", ",");
}

function ingLine(i: RecipeIngredient, factor: number) {
  const q = i.quantity != null ? `${fmt(i.quantity * factor)}${i.unit ? ` ${i.unit}` : ""} ` : "";
  return `${q}${i.name}`;
}

export default function RecipePage() {
  const { id } = useParams();
  const nav = useNavigate();
  const user = useAuth((s) => s.user);
  const plan = useEffectivePlan();
  const { data: row, isLoading, isError } = useRecipe(id);
  const { data: favs = [] } = useFavorites();
  const { data: collections = [] } = useCollections();
  const { data: collItems = [] } = useCollectionItems();
  const toggleFav = useToggleFavorite();
  const toggleColl = useToggleInCollection();
  const del = useDeleteRecipe();
  const setPublic = useSetPublic();
  const addShopping = useAddToShopping();
  const createConvo = useCreateConversation();
  const [servings, setServings] = useState<number | null>(null);
  const [showColl, setShowColl] = useState(false);

  const r = row?.data;
  const owner = !!user && row?.user_id === user.id;
  const factor = r ? (servings ?? r.servings) / r.servings : 1;
  const you = useMemo(() => r?.ingredients.filter((i) => i.have) ?? [], [r]);
  const extra = useMemo(() => r?.ingredients.filter((i) => !i.have) ?? [], [r]);

  if (isLoading) return <Spinner label="Abrindo receita…" />;
  if (isError || !row || !r) {
    return (
      <div className="space-y-3">
        <ErrorBox message="Receita não encontrada. Ela pode ter sido excluída ou não estar compartilhada com você." />
        <Link to={user ? "/minhas-receitas" : "/"}><Button variant="outline" full>Voltar</Button></Link>
      </div>
    );
  }

  const total = r.prep_minutes + r.cook_minutes;
  const shareUrl = `${window.location.origin}/receita/${row.id}`;
  const isFav = favs.includes(row.id);

  async function share() {
    if (!row!.is_public) { await setPublic.mutateAsync({ id: row!.id, isPublic: true }); }
    try {
      if (navigator.share) await navigator.share({ title: r!.title, url: shareUrl });
      else { await navigator.clipboard.writeText(shareUrl); toast.success("Link copiado!"); }
    } catch { /* usuário cancelou o compartilhamento */ }
  }

  async function askChef() {
    if (plan === "free") { toast.info("O Chef IA faz parte do plano Premium."); nav("/planos"); return; }
    const c = await createConvo.mutateAsync(row!.id);
    nav(`/chef-ia?c=${c.id}`);
  }

  return (
    <article className="space-y-5">
      <RecipeArt emoji={r.emoji} className="h-40 w-full" />
      <header className="space-y-2">
        <h1 className="text-3xl leading-tight">{r.title}</h1>
        <p className="text-muted">{r.description}</p>
        <CompatBadge r={r} />
        <div className="grid grid-cols-3 gap-2 text-center text-sm">
          <div className="card !p-3"><Clock className="mx-auto mb-1 h-4 w-4 text-brand" /><b>{total} min</b><p className="text-xs text-muted">{r.prep_minutes} preparo + {r.cook_minutes} cozimento</p></div>
          <div className="card !p-3"><ChefHat className="mx-auto mb-1 h-4 w-4 text-brand" /><b>{DIFFICULTY[r.difficulty]}</b><p className="text-xs text-muted">dificuldade</p></div>
          <div className="card !p-3"><Users className="mx-auto mb-1 h-4 w-4 text-brand" /><b>{servings ?? r.servings}</b><p className="text-xs text-muted">porções</p></div>
        </div>
      </header>

      {r.compatibility === "requer_adicional" && (
        <div className="flex gap-3 rounded-2xl border border-accent/50 bg-accent/10 p-4 text-sm" role="alert">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-accent-dark" />
          <div>
            <p className="font-semibold">Requer ingrediente adicional</p>
            <p className="text-muted">Faltam em casa: {r.missing_essentials.join(", ")}.</p>
          </div>
        </div>
      )}

      {r.allergen_warnings.length > 0 && (
        <div className="flex gap-3 rounded-2xl border-2 border-danger/50 bg-danger/5 p-4 text-sm text-danger" role="alert">
          <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" />
          <div><p className="font-bold">Atenção: alergias e restrições</p>
            <ul className="mt-1 list-disc pl-4">{r.allergen_warnings.map((w) => <li key={w}>{w}</li>)}</ul></div>
        </div>
      )}
      {r.cross_contamination.length > 0 && (
        <div className="rounded-2xl border border-danger/30 bg-white p-4 text-sm">
          <p className="font-semibold text-danger">Contaminação cruzada</p>
          <ul className="mt-1 list-disc pl-4 text-muted">{r.cross_contamination.map((w) => <li key={w}>{w}</li>)}</ul>
        </div>
      )}

      {owner && (
        <div className="grid grid-cols-2 gap-2">
          <Button variant={isFav ? "cta" : "outline"} onClick={() => toggleFav.mutate({ recipeId: row.id, on: !isFav })} aria-pressed={isFav}>
            <Heart className={cn("h-4 w-4", isFav && "fill-current")} />{isFav ? "Favorita" : "Favoritar"}
          </Button>
          <Button variant="outline" onClick={askChef}><MessageCircle className="h-4 w-4" />Perguntar ao Chef</Button>
          <Button variant="outline" onClick={() => setShowColl((s) => !s)}><FolderPlus className="h-4 w-4" />Coleção</Button>
          <Button variant="outline" onClick={share} loading={setPublic.isPending}><Share2 className="h-4 w-4" />Compartilhar</Button>
        </div>
      )}

      {owner && showColl && (
        <div className="card space-y-2">
          <p className="font-semibold text-brand">Adicionar a uma coleção</p>
          {collections.length === 0 ? (
            <p className="text-sm text-muted">Você ainda não tem coleções. Crie uma em <Link to="/minhas-receitas" className="underline">Minhas receitas</Link>.</p>
          ) : collections.map((c) => {
            const inColl = collItems.some((ci) => ci.collection_id === c.id && ci.recipe_id === row.id);
            return (
              <label key={c.id} className="flex min-h-[44px] items-center gap-3">
                <input type="checkbox" className="h-5 w-5 accent-[#1F4E3D]" checked={inColl}
                  onChange={(e) => toggleColl.mutate({ collectionId: c.id, recipeId: row.id, on: e.target.checked })} />
                {c.name}
              </label>
            );
          })}
        </div>
      )}

      {owner && row.is_public && (
        <div className="card flex items-center gap-2 !p-3 text-sm">
          <Copy className="h-4 w-4 shrink-0 text-brand" />
          <input readOnly value={shareUrl} className="min-w-0 flex-1 bg-transparent text-xs" onFocus={(e) => e.currentTarget.select()} aria-label="Link público" />
          <button className="tap px-2 font-semibold text-danger" onClick={() => setPublic.mutate({ id: row.id, isPublic: false })}>Desativar</button>
        </div>
      )}

      {/* Ingredientes */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl">Ingredientes</h2>
          <div className="flex items-center gap-1" aria-label="Ajustar porções">
            <button className="tap grid place-items-center rounded-full bg-brand-soft" aria-label="Menos porções" onClick={() => setServings(Math.max(1, (servings ?? r.servings) - 1))}><Minus className="h-4 w-4" /></button>
            <span className="w-8 text-center font-semibold">{servings ?? r.servings}</span>
            <button className="tap grid place-items-center rounded-full bg-brand-soft" aria-label="Mais porções" onClick={() => setServings(Math.min(30, (servings ?? r.servings) + 1))}><Plus className="h-4 w-4" /></button>
          </div>
        </div>
        {factor !== 1 && <p className="text-xs text-muted">Quantidades ajustadas para {servings} porções. Tempos de cozimento podem variar.</p>}

        <div className="card space-y-2">
          <h3 className="text-lg">✅ Você já tem</h3>
          {you.length === 0 ? <p className="text-sm text-muted">Nenhum ingrediente confirmado da sua despensa.</p> : (
            <ul className="space-y-1.5 text-sm">{you.map((i) => <li key={i.name} className="flex gap-2"><span className="text-brand">•</span>{ingLine(i, factor)}</li>)}</ul>
          )}
        </div>

        <div className="card space-y-2">
          <h3 className="text-lg">🛒 Ingredientes adicionais necessários</h3>
          {extra.length === 0 ? <p className="text-sm text-muted">Nenhum! Tudo vem da sua despensa.</p> : (
            <>
              <ul className="space-y-1.5 text-sm">{extra.map((i) => (
                <li key={i.name} className="flex gap-2"><span className="text-accent-dark">•</span>{ingLine(i, factor)}{!i.essential && <span className="text-xs text-muted">(opcional)</span>}</li>
              ))}</ul>
              {owner && (
                <Button variant="outline" full loading={addShopping.isPending}
                  onClick={() => addShopping.mutate(extra.map((i) => ({ name: i.name, quantity: i.quantity != null ? Math.round(i.quantity * factor * 100) / 100 : null, unit: i.unit, source_recipe_id: row.id })))}>
                  <ShoppingCart className="h-4 w-4" />Adicionar faltantes à lista de compras
                </Button>
              )}
            </>
          )}
        </div>
      </section>

      {/* Preparo */}
      <section className="space-y-3">
        <h2 className="text-2xl">Modo de preparo</h2>
        <ol className="space-y-3">
          {r.steps.map((s, i) => (
            <li key={i} className="card flex gap-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand text-sm font-bold text-white">{i + 1}</span>
              <div>{s.title && <p className="font-semibold text-brand">{s.title}</p>}<p className="text-sm">{s.text}</p></div>
            </li>
          ))}
        </ol>
      </section>

      {r.tips.length > 0 && (
        <section className="card space-y-2"><h2 className="flex items-center gap-2 text-xl"><Lightbulb className="h-5 w-5 text-accent-dark" />Dicas do chef</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm">{r.tips.map((t) => <li key={t}>{t}</li>)}</ul></section>
      )}
      {r.substitutions.length > 0 && (
        <section className="card space-y-2"><h2 className="flex items-center gap-2 text-xl"><Shuffle className="h-5 w-5 text-brand" />Substituições</h2>
          <ul className="space-y-2 text-sm">{r.substitutions.map((s) => (
            <li key={s.missing}><b>{s.missing}</b> → {s.alternative}{s.note && <span className="text-muted"> — {s.note}</span>}</li>))}</ul></section>
      )}
      {r.safety_notes.length > 0 && (
        <section className="card space-y-2"><h2 className="flex items-center gap-2 text-xl"><Flame className="h-5 w-5 text-danger" />Segurança e conservação</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm">{r.safety_notes.map((t) => <li key={t}>{t}</li>)}</ul></section>
      )}
      {r.nutrition && (
        <section className="card space-y-1 text-sm"><h2 className="text-xl">Informação nutricional <span className="text-sm font-normal text-muted">(aproximada)</span></h2>
          <p className="text-muted">Valores estimados por porção; não substituem orientação profissional.</p>
          <p>{[r.nutrition.calories != null && `${r.nutrition.calories} kcal`, r.nutrition.protein_g != null && `${r.nutrition.protein_g} g proteína`,
            r.nutrition.carbs_g != null && `${r.nutrition.carbs_g} g carboidratos`, r.nutrition.fat_g != null && `${r.nutrition.fat_g} g gorduras`].filter(Boolean).join(" · ") || "Sem estimativa."}</p>
        </section>
      )}

      <SafetyNotice>Receita gerada por IA. Use apenas alimentos bem conservados e dentro da validade; na dúvida, descarte. Confira alergias e rótulos antes de preparar.</SafetyNotice>

      {!user && (
        <div className="card space-y-2 text-center"><p className="font-display text-lg text-brand">Gostou? Crie receitas com o que você tem em casa.</p>
          <Link to="/cadastro"><Button variant="cta" full>Criar conta grátis</Button></Link></div>
      )}
      {owner && (
        <Button variant="danger" full loading={del.isPending}
          onClick={() => { if (confirm("Excluir esta receita?")) del.mutate(row.id, { onSuccess: () => nav("/minhas-receitas") }); }}>
          <Trash2 className="h-4 w-4" />Excluir receita
        </Button>
      )}
    </article>
  );
}
