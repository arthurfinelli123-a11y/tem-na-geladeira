import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { CalendarDays, ShoppingCart } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { ErrorBox, SafetyNotice } from "@/components/ui/States";
import { AiGate, PremiumGate } from "@/components/Gates";
import { ai, AiError, friendlyError } from "@/lib/ai";
import type { MealPlan } from "@/lib/schemas";
import { cn } from "@/lib/utils";

const DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];
const MEALS = ["Café da manhã", "Almoço", "Lanche", "Jantar"];

export default function Planner() {
  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Planejamento semanal</h1>
        <p className="text-sm text-muted">Refeições variadas e a lista de compras da semana.</p></div>
      <PremiumGate feature="O planejamento semanal"><AiGate><PlannerForm /></AiGate></PremiumGate>
    </div>
  );
}

function Toggle({ on, onClick, children }: { on: boolean; onClick: () => void; children: string }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick}
      className={cn("tap rounded-full border px-4 text-sm font-medium", on ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand")}>{children}</button>
  );
}

function PlannerForm() {
  const qc = useQueryClient();
  const [days, setDays] = useState<string[]>(["Segunda", "Terça", "Quarta", "Quinta", "Sexta"]);
  const [meals, setMeals] = useState<string[]>(["Almoço", "Jantar"]);
  const [preferences, setPreferences] = useState("");
  const [budget, setBudget] = useState("");
  const [usePantry, setUsePantry] = useState(true);
  const [plan, setPlan] = useState<MealPlan | null>(null);
  const [error, setError] = useState<AiError | null>(null);
  const [loading, setLoading] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const flip = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  async function submit() {
    if (!days.length || !meals.length) { toast.info("Escolha ao menos um dia e uma refeição."); return; }
    const b = budget.trim() === "" ? null : Number(budget.replace(",", "."));
    if (b !== null && (isNaN(b) || b <= 0)) { toast.error("Informe um orçamento válido."); return; }
    abort.current?.abort();
    const ctrl = new AbortController(); abort.current = ctrl;
    setLoading(true); setError(null); setPlan(null);
    try {
      const orderedDays = DAYS.filter((d) => days.includes(d));
      const orderedMeals = MEALS.filter((m) => meals.includes(m));
      const r = await ai.planWeek({ days: orderedDays, meals: orderedMeals, preferences, budget: b, usePantry }, ctrl.signal);
      setPlan(r);
      qc.invalidateQueries({ queryKey: ["lists"] }); qc.invalidateQueries({ queryKey: ["usage"] });
      toast.success("Plano pronto! A lista de compras foi criada.");
    } catch (e) {
      if (e instanceof AiError && e.code === "aborted") toast.info("Geração cancelada.");
      else setError(e instanceof AiError ? e : new AiError("unknown", friendlyError(e)));
    } finally { setLoading(false); }
  }

  return (
    <>
      <div className="card space-y-4">
        <div><span className="label">Dias</span><div className="flex flex-wrap gap-2">{DAYS.map((d) => <Toggle key={d} on={days.includes(d)} onClick={() => setDays(flip(days, d))}>{d}</Toggle>)}</div></div>
        <div><span className="label">Refeições</span><div className="flex flex-wrap gap-2">{MEALS.map((m) => <Toggle key={m} on={meals.includes(m)} onClick={() => setMeals(flip(meals, m))}>{m}</Toggle>)}</div></div>
        <div><label className="label" htmlFor="prefs">Preferências</label>
          <textarea id="prefs" rows={2} maxLength={500} className="input !min-h-[72px] py-3" placeholder="Ex.: mais legumes, pouca fritura, sem carne vermelha" value={preferences} onChange={(e) => setPreferences(e.target.value)} /></div>
        <div><label className="label" htmlFor="budget">Orçamento da semana (R$) — opcional</label>
          <input id="budget" className="input" inputMode="decimal" placeholder="Ex.: 250" value={budget} onChange={(e) => setBudget(e.target.value)} /></div>
        <label className="flex min-h-[44px] items-center gap-3 text-sm">
          <input type="checkbox" className="h-5 w-5 accent-[#1F4E3D]" checked={usePantry} onChange={(e) => setUsePantry(e.target.checked)} />
          Usar os ingredientes que já estão na minha despensa
        </label>
        <div className="flex gap-2">
          <Button variant="cta" full loading={loading} onClick={submit}><CalendarDays className="h-5 w-5" />Planejar minha semana</Button>
          {loading && <Button variant="outline" onClick={() => abort.current?.abort()}>Cancelar</Button>}
        </div>
      </div>

      {error && (
        <div className="space-y-2"><ErrorBox message={error.message} />
          {(error.code === "limit" || error.code === "plan") && <Link to="/planos"><Button variant="outline" full>Ver planos</Button></Link>}</div>
      )}

      {plan && (
        <section className="space-y-3" aria-label="Plano semanal">
          {plan.days.map((d) => (
            <div key={d.day} className="card space-y-2">
              <h2 className="text-xl">{d.day}</h2>
              <ul className="space-y-3">
                {d.meals.map((m) => (
                  <li key={m.meal} className="border-t border-brand/10 pt-2 first:border-0 first:pt-0">
                    <p className="text-xs font-semibold uppercase tracking-wide text-accent-dark">{m.meal}</p>
                    <p className="font-display text-lg text-brand">{m.title}</p>
                    <p className="text-sm text-muted">{m.description}</p>
                    {m.to_buy.length > 0 && <p className="mt-1 text-xs"><b>Comprar:</b> {m.to_buy.join(", ")}</p>}
                  </li>
                ))}
              </ul>
            </div>
          ))}
          {plan.estimated_note && <p className="text-xs text-muted">{plan.estimated_note}</p>}
          <Link to="/lista-compras"><Button variant="primary" full><ShoppingCart className="h-4 w-4" />Ver lista de compras ({plan.shopping_list.length} itens)</Button></Link>
          <SafetyNotice>Planos e estimativas de custo são sugestões da IA. Ajuste conforme suas restrições e os preços da sua região.</SafetyNotice>
        </section>
      )}
    </>
  );
}
