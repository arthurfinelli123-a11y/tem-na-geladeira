import { useMemo, useState } from "react";
import { FolderPlus, Trash2, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/Button";
import { EmptyState, Spinner } from "@/components/ui/States";
import { RecipeCard } from "@/components/RecipeCard";
import {
  useCollectionItems, useCollections, useCreateCollection, useDeleteCollection, useFavorites, useRecipes, useToggleFavorite,
} from "@/hooks/data";
import { cn } from "@/lib/utils";

type Tab = "todas" | "favoritas" | string; // string = id de coleção

export default function MyRecipes() {
  const { data: recipes = [], isLoading } = useRecipes();
  const { data: favs = [] } = useFavorites();
  const { data: collections = [] } = useCollections();
  const { data: collItems = [] } = useCollectionItems();
  const toggleFav = useToggleFavorite();
  const createColl = useCreateCollection();
  const delColl = useDeleteCollection();
  const [tab, setTab] = useState<Tab>("todas");
  const [category, setCategory] = useState("todas");
  const [q, setQ] = useState("");
  const [newName, setNewName] = useState("");

  const categories = useMemo(() => ["todas", ...new Set(recipes.map((r) => r.category).filter(Boolean))], [recipes]);

  const list = recipes.filter((r) => {
    if (tab === "favoritas" && !favs.includes(r.id)) return false;
    if (tab !== "todas" && tab !== "favoritas" && !collItems.some((c) => c.collection_id === tab && c.recipe_id === r.id)) return false;
    if (category !== "todas" && r.category !== category) return false;
    if (q.trim() && !r.title.toLowerCase().includes(q.trim().toLowerCase())) return false;
    return true;
  });
  const activeColl = collections.find((c) => c.id === tab);

  function submitColl(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim()) return;
    createColl.mutate(newName, { onSuccess: (c) => { setNewName(""); setTab(c.id); } });
  }

  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Minhas receitas</h1><p className="text-sm text-muted">Histórico, favoritas e coleções.</p></div>

      <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1" role="tablist">
        {[{ id: "todas", label: `Todas (${recipes.length})` }, { id: "favoritas", label: `❤️ Favoritas (${favs.length})` },
          ...collections.map((c) => ({ id: c.id, label: `📁 ${c.name}` }))].map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
            className={cn("tap shrink-0 whitespace-nowrap rounded-full border px-4 text-sm font-medium", tab === t.id ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand")}>{t.label}</button>
        ))}
      </div>

      <form onSubmit={submitColl} className="flex gap-2">
        <input className="input" placeholder="Nova coleção (ex.: Jantares rápidos)" maxLength={60} value={newName} onChange={(e) => setNewName(e.target.value)} aria-label="Nome da nova coleção" />
        <Button type="submit" variant="outline" loading={createColl.isPending} aria-label="Criar coleção"><FolderPlus className="h-5 w-5" /></Button>
      </form>

      {activeColl && (
        <Button variant="danger" full onClick={() => { if (confirm(`Excluir a coleção “${activeColl.name}”? As receitas não serão apagadas.`)) delColl.mutate(activeColl.id, { onSuccess: () => setTab("todas") }); }}>
          <Trash2 className="h-4 w-4" />Excluir coleção
        </Button>
      )}

      <div className="grid grid-cols-[1fr_auto] gap-2">
        <div className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input className="input pl-9" placeholder="Buscar receita" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar receita" /></div>
        <select className="input" value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Categoria">
          {categories.map((c) => <option key={c} value={c}>{c === "todas" ? "Categorias" : c}</option>)}
        </select>
      </div>

      {isLoading ? <Spinner /> : list.length === 0 ? (
        <EmptyState variant="recipes"
          title={recipes.length === 0 ? "Você ainda não tem receitas" : "Nada por aqui"}
          text={recipes.length === 0 ? "Gere sua primeira receita com os ingredientes da sua despensa." : "Ajuste a busca ou os filtros."}
          action={recipes.length === 0 ? <Link to="/gerar"><Button variant="cta">Gerar receitas</Button></Link> : undefined} />
      ) : (
        <div className="space-y-3">
          {list.map((r) => (
            <RecipeCard key={r.id} id={r.id} recipe={r.data} favorite={favs.includes(r.id)}
              onToggleFavorite={() => toggleFav.mutate({ recipeId: r.id, on: !favs.includes(r.id) })} />
          ))}
        </div>
      )}
    </div>
  );
}
