import { Link } from "react-router-dom";
import { Sparkles, Refrigerator, Camera, MessageCircle, Shuffle, CalendarDays, ShoppingCart, Wand2, Lock } from "lucide-react";
import { EmptyState } from "@/components/ui/States";
import { Button } from "@/components/ui/Button";
import { RecipeArt } from "@/components/RecipeCard";
import { useEffectivePlan, usePantry, useProfile, useRecipes, useUsageToday } from "@/hooks/data";
import { useAuth } from "@/store/auth";

const ACTIONS = [
  { to: "/gerar", label: "Gerar receitas", icon: Sparkles, premium: false },
  { to: "/ingredientes", label: "Despensa", icon: Refrigerator, premium: false },
  { to: "/foto", label: "Foto", icon: Camera, premium: true },
  { to: "/chef-ia", label: "Chef IA", icon: MessageCircle, premium: true },
  { to: "/modos", label: "Modos", icon: Wand2, premium: true },
  { to: "/substituicao", label: "Substituir", icon: Shuffle, premium: false },
  { to: "/planejamento", label: "Planejar", icon: CalendarDays, premium: true },
  { to: "/lista-compras", label: "Compras", icon: ShoppingCart, premium: false },
];

const PLAN_LABEL = { free: "Free", premium: "Premium", familia: "Família" } as const;

export default function Dashboard() {
  const user = useAuth((s) => s.user);
  const { data: profile } = useProfile();
  const { data: pantry = [] } = usePantry();
  const { data: recipes = [] } = useRecipes();
  const { data: usage = [] } = useUsageToday();
  const plan = useEffectivePlan();
  const name = (profile?.full_name ?? user?.user_metadata?.full_name ?? "").split(" ")[0];
  const generated = usage.find((u) => u.kind === "recipes")?.count ?? 0;
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl">{greet}{name ? `, ${name}` : ""}! 👋</h1>
        <p className="text-sm text-muted">O que vamos cozinhar hoje?</p>
      </header>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="card !p-3"><p className="font-display text-2xl text-brand">{pantry.filter((p) => !p.excluded).length}</p><p className="text-xs text-muted">na despensa</p></div>
        <div className="card !p-3"><p className="font-display text-2xl text-brand">{recipes.length}</p><p className="text-xs text-muted">receitas</p></div>
        <Link to="/planos" className="card !p-3"><p className="font-display text-2xl text-brand">{PLAN_LABEL[plan]}</p><p className="text-xs text-muted">{generated} gerações hoje</p></Link>
      </div>

      <section aria-label="Atalhos">
        <div className="grid grid-cols-4 gap-2">
          {ACTIONS.map(({ to, label, icon: Icon, premium }) => (
            <Link key={to} to={to} className="card tap relative flex flex-col items-center gap-1.5 !p-3 text-center">
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-brand-soft text-brand"><Icon className="h-5 w-5" /></span>
              <span className="text-[11px] font-semibold leading-tight text-brand">{label}</span>
              {premium && plan === "free" && <Lock className="absolute right-1.5 top-1.5 h-3 w-3 text-muted" aria-label="Premium" />}
            </Link>
          ))}
        </div>
      </section>

      <section aria-labelledby="recent">
        <div className="mb-2 flex items-center justify-between">
          <h2 id="recent" className="text-2xl">Receitas recentes</h2>
          {recipes.length > 0 && <Link to="/minhas-receitas" className="text-sm font-semibold text-brand underline">Ver todas</Link>}
        </div>
        {recipes.length === 0 ? (
          <EmptyState variant="recipes" title="Nenhuma receita ainda"
            text="Adicione ingredientes à despensa e peça sua primeira receita à IA."
            action={<Link to="/gerar"><Button variant="cta">Gerar minha primeira receita</Button></Link>} />
        ) : (
          <div className="space-y-2">
            {recipes.slice(0, 3).map((r) => (
              <Link key={r.id} to={`/receita/${r.id}`} className="card flex items-center gap-3 !p-3">
                <RecipeArt emoji={r.data.emoji} className="h-14 w-14 shrink-0 !rounded-xl [&>span]:text-3xl" />
                <div className="min-w-0"><p className="truncate font-display text-lg text-brand">{r.title}</p>
                  <p className="text-xs text-muted">{r.data.prep_minutes + r.data.cook_minutes} min · {new Date(r.created_at).toLocaleDateString("pt-BR")}</p></div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
