import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { Spinner } from "@/components/ui/States";
import { useProfile, useSaveProfile } from "@/hooks/data";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/store/auth";

export default function Settings() {
  const user = useAuth((s) => s.user)!;
  const nav = useNavigate();
  const qc = useQueryClient();
  const { data: profile, isLoading } = useProfile();
  const save = useSaveProfile();
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [installEvt, setInstallEvt] = useState<Event | null>(null);

  // Prompt de instalação do PWA
  useEffect(() => {
    const onPrompt = (e: Event) => { e.preventDefault(); setInstallEvt(e); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  async function changePassword() {
    if (pw.length < 8) { toast.error("Use ao menos 8 caracteres."); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) toast.error("Não foi possível alterar a senha. Entre novamente e tente de novo.");
    else { toast.success("Senha alterada."); setPw(""); }
  }

  async function exportData() {
    setBusy(true);
    try {
      const tables = ["profiles", "pantry_items", "recipes_generated", "favorites", "collections", "collection_items", "chat_conversations", "chat_messages", "shopping_lists", "shopping_items", "meal_plans"];
      const out: Record<string, unknown> = {};
      for (const t of tables) {
        const { data, error } = await supabase.from(t).select("*");
        if (error) throw error;
        out[t] = data;
      }
      const blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = "meus-dados-tem-na-geladeira.json"; a.click();
      URL.revokeObjectURL(a.href);
      toast.success("Seus dados foram exportados.");
    } catch { toast.error("Não foi possível exportar agora."); } finally { setBusy(false); }
  }

  async function logoutAll() {
    await supabase.auth.signOut({ scope: "global" });
    qc.clear(); toast.success("Você saiu de todos os dispositivos."); nav("/");
  }

  if (isLoading) return <Spinner />;

  return (
    <div className="space-y-4">
      <h1 className="text-3xl">Configurações</h1>

      <section className="card space-y-3">
        <h2 className="text-xl">Privacidade e IA</h2>
        <label className="flex min-h-[44px] items-start gap-3 text-sm">
          <input type="checkbox" className="mt-0.5 h-5 w-5 accent-[#1F4E3D]" checked={!!profile?.ai_consent}
            onChange={(e) => save.mutate({ ai_consent: e.target.checked })} />
          <span>Permitir que a IA use minha despensa, preferências e restrições para criar receitas. Sem esta permissão, os recursos de IA ficam desativados.</span>
        </label>
        <Link to="/privacidade" className="text-sm font-semibold text-brand underline">Política de privacidade</Link>
      </section>

      <section className="card space-y-3">
        <h2 className="text-xl">Conta</h2>
        <p className="text-sm text-muted">{user.email}</p>
        <div><label className="label" htmlFor="pw">Nova senha</label>
          <input id="pw" type="password" className="input" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
        <Button full loading={busy} onClick={changePassword} disabled={!pw}>Alterar senha</Button>
        <Button variant="outline" full onClick={logoutAll}>Sair de todos os dispositivos</Button>
      </section>

      <section className="card space-y-3">
        <h2 className="text-xl">Seus dados</h2>
        <p className="text-sm text-muted">Baixe uma cópia de tudo o que está salvo na sua conta.</p>
        <Button variant="outline" full loading={busy} onClick={exportData}>Exportar meus dados (JSON)</Button>
        <p className="text-xs text-muted">Para excluir sua conta e todos os dados, solicite pelo e-mail de suporte indicado na Política de privacidade.</p>
      </section>

      <section className="card space-y-3">
        <h2 className="text-xl">Instalar o app</h2>
        {installEvt ? (
          <Button full onClick={async () => { (installEvt as unknown as { prompt: () => Promise<void> }).prompt(); setInstallEvt(null); }}>Instalar Tem na Geladeira</Button>
        ) : (
          <p className="text-sm text-muted">No celular, abra o menu do navegador e toque em “Adicionar à tela inicial”.</p>
        )}
      </section>
    </div>
  );
}
