import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { Send, Square, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { EmptyState, ErrorBox, Spinner } from "@/components/ui/States";
import { AiGate, PremiumGate } from "@/components/Gates";
import { ai, AiError, friendlyError } from "@/lib/ai";
import { useConversations, useCreateConversation, useDeleteConversation, useMessages } from "@/hooks/data";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Não tenho fermento. Posso fazer um bolo?",
  "O que posso fazer com o que tenho na despensa?",
  "Como deixar o arroz soltinho?",
  "Adapte uma receita para 4 pessoas",
];

export default function Chef() {
  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Chef IA</h1><p className="text-sm text-muted">Converse com seu chef pessoal.</p></div>
      <PremiumGate feature="O Chef IA"><AiGate><Chat /></AiGate></PremiumGate>
    </div>
  );
}

function Chat() {
  const [params, setParams] = useSearchParams();
  const qc = useQueryClient();
  const { data: convos = [], isLoading } = useConversations();
  const create = useCreateConversation();
  const del = useDeleteConversation();
  const activeId = params.get("c");
  const { data: messages = [], isLoading: loadingMsgs } = useMessages(activeId);
  const [input, setInput] = useState("");
  const [pendingUser, setPendingUser] = useState<string | null>(null);
  const [streaming, setStreaming] = useState<string | null>(null);
  const [error, setError] = useState<AiError | null>(null);
  const abort = useRef<AbortController | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const busy = streaming !== null;

  // Seleciona a conversa mais recente se nenhuma estiver ativa.
  useEffect(() => {
    if (!activeId && convos.length > 0) setParams({ c: convos[0].id }, { replace: true });
  }, [activeId, convos, setParams]);

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, streaming, pendingUser]);

  const active = convos.find((c) => c.id === activeId);

  async function newChat() {
    const c = await create.mutateAsync(null);
    setParams({ c: c.id });
  }

  async function send(text: string) {
    const message = text.trim();
    if (!message || busy) return;
    let convoId = activeId;
    if (!convoId) { const c = await create.mutateAsync(null); convoId = c.id; setParams({ c: c.id }, { replace: true }); }

    setError(null); setInput(""); setPendingUser(message); setStreaming("");
    const ctrl = new AbortController(); abort.current = ctrl;
    try {
      await ai.chat({ conversationId: convoId, message, recipeId: active?.recipe_id ?? null },
        (t) => setStreaming((s) => (s ?? "") + t), ctrl.signal);
    } catch (e) {
      if (!(e instanceof AiError && e.code === "aborted")) setError(e instanceof AiError ? e : new AiError("unknown", friendlyError(e)));
    } finally {
      // O servidor já salvou as mensagens; recarregamos do banco e limpamos o estado temporário.
      await qc.invalidateQueries({ queryKey: ["messages", convoId] });
      qc.invalidateQueries({ queryKey: ["convos"] });
      qc.invalidateQueries({ queryKey: ["usage"] });
      setPendingUser(null); setStreaming(null);
    }
  }

  if (isLoading) return <Spinner />;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-2">
        <select className="input flex-1" aria-label="Conversas" value={activeId ?? ""} onChange={(e) => setParams(e.target.value ? { c: e.target.value } : {})}>
          {convos.length === 0 && <option value="">Nenhuma conversa</option>}
          {convos.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
        </select>
        <Button variant="outline" onClick={newChat} loading={create.isPending} aria-label="Nova conversa"><Plus className="h-5 w-5" /></Button>
        {active && (
          <Button variant="danger" aria-label="Apagar conversa"
            onClick={() => { if (confirm("Apagar esta conversa?")) del.mutate(active.id, { onSuccess: () => setParams({}) }); }}><Trash2 className="h-4 w-4" /></Button>
        )}
      </div>

      {active?.recipe_id && (
        <p className="text-xs text-muted">Conversa sobre uma receita. <Link to={`/receita/${active.recipe_id}`} className="font-semibold text-brand underline">Abrir receita</Link></p>
      )}

      <div className="card min-h-[320px] space-y-3 !p-3" aria-live="polite">
        {loadingMsgs ? <Spinner /> : messages.length === 0 && !pendingUser ? (
          <EmptyState variant="chat" title="Pergunte ao chef"
            text="O Chef conhece sua despensa. Peça ideias, substituições ou ajuda com qualquer receita."
            action={<div className="flex flex-wrap justify-center gap-2">{SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="chip tap hover:bg-brand-light/50">{s}</button>))}</div>} />
        ) : (
          <>
            {messages.map((m) => <Bubble key={m.id} role={m.role} text={m.content} />)}
            {pendingUser && <Bubble role="user" text={pendingUser} />}
            {streaming !== null && <Bubble role="assistant" text={streaming || "…"} />}
          </>
        )}
        <div ref={bottom} />
      </div>

      {error && (
        <div className="space-y-2"><ErrorBox message={error.message} />
          {(error.code === "limit" || error.code === "plan") && <Link to="/planos"><Button variant="outline" full>Ver planos</Button></Link>}</div>
      )}

      <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="sticky bottom-20 flex items-end gap-2 md:bottom-4">
        <textarea
          value={input} onChange={(e) => setInput(e.target.value)} rows={1} maxLength={2000} disabled={busy}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
          className="input !min-h-[48px] flex-1 resize-none py-3 shadow-soft" placeholder="Escreva sua pergunta…" aria-label="Mensagem"
        />
        {busy ? (
          <Button type="button" variant="outline" aria-label="Parar resposta" onClick={() => abort.current?.abort()}><Square className="h-4 w-4" /></Button>
        ) : (
          <Button type="submit" variant="cta" disabled={!input.trim()} aria-label="Enviar"><Send className="h-5 w-5" /></Button>
        )}
      </form>
      <p className="text-center text-[11px] text-muted" onClick={() => toast.info("O Chef pode errar. Confira alergias e a validade dos alimentos.")}>
        O Chef IA pode cometer erros. Confira alergias, validade e cozimento seguro.
      </p>
    </div>
  );
}

function Bubble({ role, text }: { role: "user" | "assistant"; text: string }) {
  return (
    <div className={cn("flex", role === "user" ? "justify-end" : "justify-start")}>
      <div className={cn("max-w-[88%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
        role === "user" ? "rounded-br-md bg-brand text-white" : "rounded-bl-md bg-brand-soft text-ink")}>{text}</div>
    </div>
  );
}
