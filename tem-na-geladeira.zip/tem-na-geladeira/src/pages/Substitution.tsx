import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { ErrorBox, SafetyNotice } from "@/components/ui/States";
import { AiGate } from "@/components/Gates";
import { ai, AiError, friendlyError } from "@/lib/ai";
import type { SubstitutionResult } from "@/lib/schemas";
import { usePantry } from "@/hooks/data";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  missing: z.string().trim().min(2, "Diga qual ingrediente está faltando.").max(80),
  recipe: z.string().trim().min(2, "Diga qual receita você quer fazer.").max(200),
  available: z.string().max(400).optional(),
});
type Form = z.infer<typeof formSchema>;

const VERDICT = {
  funciona: { label: "Funciona", icon: CheckCircle2, cls: "bg-brand-soft text-brand" },
  ressalvas: { label: "Funciona com ressalvas", icon: AlertTriangle, cls: "bg-accent/20 text-ink" },
  nao_recomendado: { label: "Não recomendado", icon: XCircle, cls: "bg-danger/10 text-danger" },
} as const;

export default function Substitution() {
  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Substituição inteligente</h1>
        <p className="text-sm text-muted">Faltou um ingrediente? Descubra se dá para trocar.</p></div>
      <AiGate><SubForm /></AiGate>
    </div>
  );
}

function SubForm() {
  const { data: pantry = [] } = usePantry();
  const [result, setResult] = useState<SubstitutionResult | null>(null);
  const [error, setError] = useState<AiError | null>(null);
  const [loading, setLoading] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const { register, handleSubmit, setValue, getValues, formState: { errors } } = useForm<Form>({ resolver: zodResolver(formSchema) });

  async function onSubmit(v: Form) {
    abort.current?.abort();
    const ctrl = new AbortController(); abort.current = ctrl;
    setLoading(true); setError(null); setResult(null);
    try {
      const available = (v.available ?? "").split(/[,;\n]/).map((s) => s.trim()).filter(Boolean);
      setResult(await ai.substitute({ missing: v.missing, recipe: v.recipe, available }, ctrl.signal));
    } catch (e) {
      if (!(e instanceof AiError && e.code === "aborted")) setError(e instanceof AiError ? e : new AiError("unknown", friendlyError(e)));
    } finally { setLoading(false); }
  }

  function addFromPantry(name: string) {
    const cur = (getValues("available") ?? "").split(/[,;\n]/).map((s) => s.trim()).filter(Boolean);
    if (!cur.includes(name)) setValue("available", [...cur, name].join(", "));
  }

  const v = result ? VERDICT[result.verdict] : null;

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className="card space-y-4" noValidate>
        <div>
          <label className="label" htmlFor="missing">Ingrediente que falta</label>
          <input id="missing" className="input" placeholder="Ex.: fermento em pó" {...register("missing")} />
          {errors.missing && <p className="mt-1 text-sm text-danger" role="alert">{errors.missing.message}</p>}
        </div>
        <div>
          <label className="label" htmlFor="recipe">Receita</label>
          <input id="recipe" className="input" placeholder="Ex.: bolo de cenoura" {...register("recipe")} />
          {errors.recipe && <p className="mt-1 text-sm text-danger" role="alert">{errors.recipe.message}</p>}
        </div>
        <div>
          <label className="label" htmlFor="available">Alternativas que você tem</label>
          <textarea id="available" rows={2} className="input !min-h-[72px] py-3" placeholder="Ex.: bicarbonato, vinagre, iogurte" {...register("available")} />
          {pantry.filter((p) => !p.excluded).length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5" aria-label="Adicionar da despensa">
              {pantry.filter((p) => !p.excluded).slice(0, 14).map((p) => (
                <button type="button" key={p.id} onClick={() => addFromPantry(p.name)} className="chip tap !min-h-[36px] hover:bg-brand-light/50">+ {p.name}</button>
              ))}
            </div>
          )}
        </div>
        <Button type="submit" variant="cta" full loading={loading}>Ver substituição</Button>
      </form>

      {error && (
        <div className="space-y-2"><ErrorBox message={error.message} />
          {(error.code === "limit" || error.code === "plan") && <Link to="/planos"><Button variant="outline" full>Ver planos</Button></Link>}</div>
      )}

      {result && v && (
        <section className="card space-y-3" aria-live="polite">
          <div className={cn("flex items-center gap-2 rounded-2xl px-3 py-2 font-semibold", v.cls)}><v.icon className="h-5 w-5" />{v.label}</div>
          <dl className="space-y-3 text-sm">
            <div><dt className="font-semibold text-brand">Substituição ideal</dt><dd>{result.ideal}</dd></div>
            <div><dt className="font-semibold text-brand">Quantidade</dt><dd>{result.quantity}</dd></div>
            <div><dt className="font-semibold text-brand">Impacto na textura</dt><dd>{result.texture_impact}</dd></div>
            <div><dt className="font-semibold text-brand">Impacto no sabor</dt><dd>{result.flavor_impact}</dd></div>
            {result.notes && <div><dt className="font-semibold text-brand">Observações</dt><dd>{result.notes}</dd></div>}
          </dl>
          <SafetyNotice>Confira alergias e restrições antes de usar qualquer substituto.</SafetyNotice>
        </section>
      )}
    </>
  );
}
