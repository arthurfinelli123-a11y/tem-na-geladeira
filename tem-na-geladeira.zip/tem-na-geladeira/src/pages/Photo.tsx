import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Camera, Image as ImageIcon, X, Plus, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { ErrorBox, SafetyNotice } from "@/components/ui/States";
import { AiGate, PremiumGate } from "@/components/Gates";
import { ai, AiError, friendlyError } from "@/lib/ai";
import { useAddPantry } from "@/hooks/data";
import { CATEGORIES } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface Detected { key: number; name: string; category: string; confidence: "alta" | "media" | "baixa"; keep: boolean }

/** Reduz a imagem para ~1280px e JPEG: envia menos dados e respeita o limite do servidor. */
async function prepareImage(file: File): Promise<{ base64: string; mediaType: string; preview: string }> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
  return { base64: dataUrl.split(",")[1], mediaType: "image/jpeg", preview: dataUrl };
}

export default function Photo() {
  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Reconhecer por foto</h1>
        <p className="text-sm text-muted">Fotografe a geladeira, a despensa ou os ingredientes.</p></div>
      <PremiumGate feature="O reconhecimento por foto"><AiGate><PhotoFlow /></AiGate></PremiumGate>
    </div>
  );
}

function PhotoFlow() {
  const nav = useNavigate();
  const add = useAddPantry();
  const camera = useRef<HTMLInputElement>(null);
  const gallery = useRef<HTMLInputElement>(null);
  const abort = useRef<AbortController | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [payload, setPayload] = useState<{ base64: string; mediaType: string } | null>(null);
  const [items, setItems] = useState<Detected[] | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [manual, setManual] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<AiError | null>(null);
  const [saved, setSaved] = useState(false);

  async function onFile(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Escolha um arquivo de imagem."); return; }
    try {
      const p = await prepareImage(file);
      setPreview(p.preview); setPayload({ base64: p.base64, mediaType: p.mediaType });
      setItems(null); setError(null); setConfirmed(false); setSaved(false);
    } catch { toast.error("Não consegui abrir essa imagem. Tente outra."); }
  }

  async function analyze() {
    if (!payload) return;
    abort.current?.abort();
    const ctrl = new AbortController(); abort.current = ctrl;
    setLoading(true); setError(null);
    try {
      const r = await ai.analyzePhoto({ imageBase64: payload.base64, mediaType: payload.mediaType }, ctrl.signal);
      setItems(r.items.map((i, n) => ({ key: n, name: i.name, category: i.category, confidence: i.confidence, keep: true })));
      if (r.items.length === 0) toast.info("Não identifiquei ingredientes. Tente uma foto mais nítida ou adicione manualmente.");
    } catch (e) {
      if (!(e instanceof AiError && e.code === "aborted")) setError(e instanceof AiError ? e : new AiError("unknown", friendlyError(e)));
    } finally { setLoading(false); }
  }

  function patch(key: number, p: Partial<Detected>) { setItems((l) => l?.map((i) => (i.key === key ? { ...i, ...p } : i)) ?? l); }
  function addManual() {
    const n = manual.trim(); if (!n) return;
    setItems((l) => [...(l ?? []), { key: Date.now(), name: n, category: "outros", confidence: "alta", keep: true }]); setManual("");
  }

  function save() {
    const chosen = (items ?? []).filter((i) => i.keep && i.name.trim());
    if (chosen.length === 0) { toast.info("Selecione ao menos um ingrediente."); return; }
    add.mutate(chosen.map((i) => ({ name: i.name.trim(), category: i.category })), {
      onSuccess: () => { setSaved(true); toast.success(`${chosen.length} ingredientes salvos na despensa.`); },
    });
  }

  return (
    <>
      <SafetyNotice>A identificação é uma sugestão e não confirma que o alimento está próprio para consumo.</SafetyNotice>

      <div className="card space-y-3">
        <input ref={camera} type="file" accept="image/*" capture="environment" hidden onChange={(e) => onFile(e.target.files?.[0])} />
        <input ref={gallery} type="file" accept="image/*" hidden onChange={(e) => onFile(e.target.files?.[0])} />
        <div className="grid grid-cols-2 gap-2">
          <Button variant="primary" onClick={() => camera.current?.click()}><Camera className="h-4 w-4" />Tirar foto</Button>
          <Button variant="outline" onClick={() => gallery.current?.click()}><ImageIcon className="h-4 w-4" />Da galeria</Button>
        </div>
        {preview && <img src={preview} alt="Foto enviada" className="max-h-72 w-full rounded-2xl object-cover" />}
        {preview && !items && (
          <div className="flex gap-2">
            <Button variant="cta" full loading={loading} onClick={analyze}>Identificar ingredientes</Button>
            {loading && <Button variant="outline" onClick={() => abort.current?.abort()}>Cancelar</Button>}
          </div>
        )}
      </div>

      {error && (
        <div className="space-y-2"><ErrorBox message={error.message} />
          {(error.code === "limit" || error.code === "plan") && <Link to="/planos"><Button variant="outline" full>Ver planos</Button></Link>}</div>
      )}

      {items && (
        <section className="card space-y-3" aria-label="Ingredientes identificados">
          <h2 className="text-xl">Confira o que a IA viu</h2>
          <p className="text-sm text-muted">Corrija nomes, desmarque o que estiver errado e adicione o que faltou.</p>
          <ul className="space-y-2">
            {items.map((i) => (
              <li key={i.key} className={cn("flex items-center gap-2 rounded-2xl border p-2", i.keep ? "border-brand/20" : "border-dashed border-muted/40 opacity-60")}>
                <input type="checkbox" className="h-5 w-5 accent-[#1F4E3D]" checked={i.keep} onChange={(e) => patch(i.key, { keep: e.target.checked })} aria-label={`Manter ${i.name}`} />
                <div className="min-w-0 flex-1 space-y-1">
                  <input className="input !min-h-[40px] py-1" value={i.name} maxLength={80} onChange={(e) => patch(i.key, { name: e.target.value })} aria-label="Nome do ingrediente" />
                  <div className="flex items-center gap-2">
                    <select className="input !min-h-[36px] py-0 text-sm" value={i.category} onChange={(e) => patch(i.key, { category: e.target.value })} aria-label="Categoria">
                      {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
                    </select>
                    {i.confidence === "baixa" && <span className="shrink-0 text-xs font-semibold text-accent-dark">incerto</span>}
                  </div>
                </div>
                <button className="tap grid place-items-center text-muted" onClick={() => setItems((l) => l?.filter((x) => x.key !== i.key) ?? l)} aria-label={`Remover ${i.name}`}><X className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
          <div className="flex gap-2">
            <input className="input" placeholder="Adicionar item que faltou" value={manual} maxLength={80} onChange={(e) => setManual(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addManual(); } }} />
            <Button variant="outline" onClick={addManual} aria-label="Adicionar item"><Plus className="h-4 w-4" /></Button>
          </div>

          <label className="flex min-h-[44px] items-start gap-3 text-sm">
            <input type="checkbox" className="mt-0.5 h-5 w-5 accent-[#1F4E3D]" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            <span>Conferi a lista e confirmo que tenho estes itens, em bom estado para consumo.</span>
          </label>

          {!saved ? (
            <Button variant="cta" full disabled={!confirmed} loading={add.isPending} onClick={save}><Check className="h-4 w-4" />Salvar na despensa</Button>
          ) : (
            <Button full onClick={() => nav("/gerar")}>Gerar receitas agora</Button>
          )}
        </section>
      )}
    </>
  );
}
