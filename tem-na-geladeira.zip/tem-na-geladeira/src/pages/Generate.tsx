import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useForm, Controller, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Sparkles, Square, Lock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { ErrorBox, SafetyNotice } from "@/components/ui/States";
import { AiGate } from "@/components/Gates";
import { RecipeCard } from "@/components/RecipeCard";
import { ai, AiError, friendlyError } from "@/lib/ai";
import { generateParamsSchema, type GenerateParams, type Recipe } from "@/lib/schemas";
import { EQUIPMENT, MEAL_TYPES, MODES } from "@/lib/modes";
import { useEffectivePlan, useFavorites, usePantry, useProfile, useToggleFavorite, useUsageToday } from "@/hooks/data";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

type Result = { recipes: Recipe[]; ids: string[] };

export default function Generate() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl">Gerar receitas</h1>
        <p className="text-sm text-muted">Receitas criadas pela IA com o que está na sua despensa.</p>
      </div>
      <AiGate><GenerateForm /></AiGate>
    </div>
  );
}

function GenerateForm() {
  const [params] = useSearchParams();
  const qc = useQueryClient();
  const plan = useEffectivePlan();
  const { data: profile } = useProfile();
  const { data: pantry = [] } = usePantry();
  const { data: favs = [] } = useFavorites();
  const { data: usage = [] } = useUsageToday();
  const toggleFav = useToggleFavorite();
  const have = pantry.filter((p) => !p.excluded);

  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState<AiError | null>(null);
  const [loading, setLoading] = useState(false);
  const abort = useRef<AbortController | null>(null);

  const initialMode = params.get("mode");
  const { control, handleSubmit, watch, setValue, reset } = useForm<GenerateParams>({
    resolver: zodResolver(generateParamsSchema) as Resolver<GenerateParams>,
    defaultValues: {
      mealType: (params.get("mealType") as GenerateParams["mealType"]) ?? "qualquer",
      servings: 2,
      maxMinutes: params.get("maxMinutes") ? Number(params.get("maxMinutes")) : null,
      difficulty: "qualquer",
      mode: initialMode, modeOption: params.get("modeOption"), equipment: [],
    },
  });

  // Porções habituais e equipamentos do perfil (aplicados uma vez quando o perfil chega).
  useEffect(() => {
    if (profile) setValue("servings", profile.default_servings);
    if (profile?.equipment?.length) setValue("equipment", profile.equipment);
  }, [profile, setValue]);

  const mode = watch("mode");
  const modeDef = MODES.find((m) => m.id === mode);
  const used = usage.find((u) => u.kind === "recipes")?.count ?? 0;

  async function onSubmit(values: GenerateParams) {
    if (have.length === 0) { toast.info("Adicione ingredientes à despensa primeiro."); return; }
    abort.current?.abort();
    const ctrl = new AbortController();
    abort.current = ctrl;
    setLoading(true); setError(null); setResult(null);
    try {
      const r = await ai.generateRecipes(values, ctrl.signal);
      setResult({ recipes: r.recipes, ids: r.ids });
      qc.invalidateQueries({ queryKey: ["recipes"] });
      qc.invalidateQueries({ queryKey: ["usage"] });
      toast.success(`${r.recipes.length} receitas prontas!`);
    } catch (e) {
      if (e instanceof AiError && e.code === "aborted") toast.info("Geração cancelada.");
      else setError(e instanceof AiError ? e : new AiError("unknown", friendlyError(e)));
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="card flex items-center justify-between !py-3">
        <p className="text-sm"><b>{have.length}</b> {have.length === 1 ? "ingrediente" : "ingredientes"} na despensa</p>
        <Link to="/ingredientes" className="tap flex items-center text-sm font-semibold text-brand underline">Editar</Link>
      </div>
      {plan === "free" && <p className="text-xs text-muted">Plano Free · {used} gerações usadas hoje.</p>}

      <form onSubmit={handleSubmit(onSubmit)} className="card space-y-4" noValidate>
        <div>
          <span className="label">Tipo de refeição</span>
          <Controller control={control} name="mealType" render={({ field }) => (
            <div className="flex flex-wrap gap-2">
              {MEAL_TYPES.map((m) => (
                <button type="button" key={m.id} onClick={() => field.onChange(m.id)} aria-pressed={field.value === m.id}
                  className={cn("tap rounded-full border px-4 text-sm font-medium", field.value === m.id ? "border-brand bg-brand text-white" : "border-brand/20 bg-white text-brand")}>
                  {m.label}
                </button>
              ))}
            </div>
          )} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="servings">Pessoas</label>
            <Controller control={control} name="servings" render={({ field }) => (
              <input id="servings" type="number" min={1} max={20} inputMode="numeric" className="input" value={field.value}
                onChange={(e) => field.onChange(Math.max(1, Math.min(20, Number(e.target.value) || 1)))} />
            )} />
          </div>
          <div>
            <label className="label" htmlFor="time">Tempo máx. (min)</label>
            <Controller control={control} name="maxMinutes" render={({ field }) => (
              <input id="time" type="number" min={5} max={240} inputMode="numeric" placeholder="Sem limite" className="input" value={field.value ?? ""}
                onChange={(e) => field.onChange(e.target.value === "" ? null : Math.max(5, Math.min(240, Number(e.target.value))))} />
            )} />
          </div>
        </div>

        <div>
          <label className="label" htmlFor="diff">Dificuldade</label>
          <Controller control={control} name="difficulty" render={({ field }) => (
            <select id="diff" className="input" {...field}>
              <option value="qualquer">Qualquer</option><option value="facil">Fácil</option>
              <option value="medio">Médio</option><option value="dificil">Difícil</option>
            </select>
          )} />
        </div>

        <div>
          <span className="label">Equipamentos</span>
          <Controller control={control} name="equipment" render={({ field }) => (
            <div className="flex flex-wrap gap-2">
              {EQUIPMENT.map((e) => {
                const on = field.value.includes(e);
                return (
                  <button type="button" key={e} aria-pressed={on}
                    onClick={() => field.onChange(on ? field.value.filter((x) => x !== e) : [...field.value, e])}
                    className={cn("tap rounded-full border px-3 text-sm", on ? "border-brand bg-brand-soft font-semibold text-brand" : "border-brand/20 bg-white text-muted")}>
                    {e}
                  </button>
                );
              })}
            </div>
          )} />
        </div>

        <div>
          <span className="label">Modo especial {plan === "free" && <Lock className="ml-1 inline h-3.5 w-3.5" />}</span>
          {plan === "free" ? (
            <p className="text-sm text-muted">Os modos especiais fazem parte do plano Premium. <Link to="/planos" className="font-semibold text-brand underline">Ver planos</Link></p>
          ) : (
            <>
              <Controller control={control} name="mode" render={({ field }) => (
                <select className="input" value={field.value ?? ""} aria-label="Modo especial"
                  onChange={(e) => { field.onChange(e.target.value || null); setValue("modeOption", null); }}>
                  <option value="">Nenhum</option>
                  {MODES.map((m) => <option key={m.id} value={m.id}>{m.emoji} {m.label}</option>)}
                </select>
              )} />
              {modeDef && <p className="mt-1 text-xs text-muted">{modeDef.description}</p>}
              {modeDef?.option && (
                <Controller control={control} name="modeOption" render={({ field }) => (
                  modeDef.option!.free ? (
                    <input className="input mt-2" list="mode-options" placeholder={modeDef.option!.label} value={field.value ?? ""} maxLength={40}
                      onChange={(e) => field.onChange(e.target.value || null)} />
                  ) : (
                    <select className="input mt-2" value={field.value ?? ""} onChange={(e) => field.onChange(e.target.value || null)} aria-label={modeDef.option!.label}>
                      <option value="">{modeDef.option!.label}</option>
                      {modeDef.option!.choices.map((c) => <option key={c} value={c}>{c} min</option>)}
                    </select>
                  )
                )} />
              )}
              <datalist id="mode-options">{modeDef?.option?.choices.map((c) => <option key={c} value={c} />)}</datalist>
            </>
          )}
        </div>

        <div className="flex gap-2">
          <Button type="submit" variant="cta" full loading={loading} disabled={loading}>
            <Sparkles className="h-5 w-5" />{loading ? "Criando receitas…" : "Gerar receitas com IA"}
          </Button>
          {loading && (
            <Button type="button" variant="outline" aria-label="Cancelar geração" onClick={() => abort.current?.abort()}><Square className="h-4 w-4" />Cancelar</Button>
          )}
        </div>
        <button type="button" className="tap text-sm text-muted underline" onClick={() => reset()}>Limpar filtros</button>
      </form>

      {loading && <LoadingChef />}

      {error && (
        <div className="space-y-2">
          <ErrorBox message={error.message} />
          {(error.code === "plan" || error.code === "limit") && <Link to="/planos"><Button variant="outline" full>Ver planos</Button></Link>}
          {error.code === "consent" && <Link to="/configuracoes"><Button variant="outline" full>Abrir configurações</Button></Link>}
        </div>
      )}

      {result && (
        <section className="space-y-3" aria-label="Receitas geradas">
          <h2 className="text-2xl">Suas receitas</h2>
          <SafetyNotice>
            Confira sempre alergias, rótulos e a validade dos alimentos. Informações nutricionais, quando presentes, são aproximadas.
          </SafetyNotice>
          {result.recipes.map((r, i) => {
            const id = result.ids[i];
            return id ? (
              <RecipeCard key={id} id={id} recipe={r} favorite={favs.includes(id)}
                onToggleFavorite={() => toggleFav.mutate({ recipeId: id, on: !favs.includes(id) })} />
            ) : null;
          })}
          <p className="text-center text-xs text-muted">As receitas ficam salvas em <Link className="underline" to="/minhas-receitas">Minhas receitas</Link>.</p>
        </section>
      )}
    </>
  );
}

function LoadingChef() {
  return (
    <div className="card flex flex-col items-center gap-3 py-8 text-center" role="status" aria-live="polite">
      <span className="h-10 w-10 animate-spin rounded-full border-4 border-brand/15 border-t-accent" />
      <p className="font-display text-lg text-brand">O chef está pensando…</p>
      <p className="text-xs text-muted">Isso pode levar até 30 segundos. Você pode cancelar a qualquer momento.</p>
    </div>
  );
}
