import { useEffect, useMemo, useState } from "react";
import { Archive, ArchiveRestore, Plus, Trash2, ListPlus, Pencil, Check, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/Button";
import { EmptyState, Spinner } from "@/components/ui/States";
import { IngredientInput } from "@/components/IngredientInput";
import {
  useAddShoppingItems, useCreateList, useRemoveShoppingItem, useShoppingItems, useShoppingLists,
  useUpdateList, useUpdateShoppingItem,
} from "@/hooks/data";
import { CATEGORIES, UNITS } from "@/lib/utils";
import type { ShoppingItem } from "@/lib/types";
import { cn } from "@/lib/utils";

export default function Shopping() {
  const { data: lists = [], isLoading } = useShoppingLists();
  const createList = useCreateList();
  const updateList = useUpdateList();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [showArchived, setShowArchived] = useState(false);

  const visible = lists.filter((l) => l.archived === showArchived);
  const active = lists.find((l) => l.id === activeId) ?? visible[0] ?? null;

  useEffect(() => { if (!activeId && visible[0]) setActiveId(visible[0].id); }, [activeId, visible]);

  const { data: items = [], isLoading: loadingItems } = useShoppingItems(active?.id ?? null);
  const addItems = useAddShoppingItems();
  const updateItem = useUpdateShoppingItem();
  const removeItem = useRemoveShoppingItem();
  const [editing, setEditing] = useState<string | null>(null);

  const grouped = useMemo(() => CATEGORIES.map((c) => ({
    ...c, items: items.filter((i) => i.category === c.id).sort((a, b) => Number(a.checked) - Number(b.checked)),
  })).filter((g) => g.items.length), [items]);
  const pending = items.filter((i) => !i.checked).length;

  async function newList() {
    const name = prompt("Nome da nova lista:", "Nova lista");
    if (name === null) return;
    const l = await createList.mutateAsync(name);
    setShowArchived(false); setActiveId(l.id); toast.success("Lista criada.");
  }

  return (
    <div className="space-y-4">
      <div><h1 className="text-3xl">Lista de compras</h1><p className="text-sm text-muted">Organizada por categoria. Receitas e planejamento enviam itens para cá.</p></div>

      <div className="flex gap-2">
        <select className="input flex-1" value={active?.id ?? ""} onChange={(e) => setActiveId(e.target.value)} aria-label="Escolher lista">
          {visible.length === 0 && <option value="">{showArchived ? "Nenhuma lista salva" : "Nenhuma lista"}</option>}
          {visible.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
        <Button variant="outline" onClick={newList} aria-label="Nova lista"><ListPlus className="h-5 w-5" /></Button>
      </div>
      <div className="flex gap-2 text-sm">
        <button className={cn("tap rounded-full px-4", !showArchived ? "bg-brand text-white" : "bg-brand-soft text-brand")} onClick={() => { setShowArchived(false); setActiveId(null); }}>Ativas</button>
        <button className={cn("tap rounded-full px-4", showArchived ? "bg-brand text-white" : "bg-brand-soft text-brand")} onClick={() => { setShowArchived(true); setActiveId(null); }}>Listas anteriores</button>
        {active && (
          <button className="tap ml-auto flex items-center gap-1 text-brand underline"
            onClick={() => updateList.mutate({ id: active.id, archived: !active.archived }, { onSuccess: () => { toast.success(active.archived ? "Lista reativada." : "Lista salva em “anteriores”."); setActiveId(null); } })}>
            {active.archived ? <><ArchiveRestore className="h-4 w-4" />Reativar</> : <><Archive className="h-4 w-4" />Arquivar</>}
          </button>
        )}
      </div>

      {isLoading ? <Spinner /> : !active ? (
        <EmptyState variant="list" title="Nenhuma lista aqui" text="Crie uma lista para começar a anotar o que falta."
          action={!showArchived && <Button onClick={newList}><Plus className="h-4 w-4" />Criar lista</Button>} />
      ) : (
        <>
          {!active.archived && (
            <div className="card">
              <IngredientInput placeholder="Adicionar item à lista…"
                onAdd={(name, category) => addItems.mutate({ listId: active.id, items: [{ name, category }] }, { onSuccess: () => toast.success(`“${name}” adicionado.`) })} />
            </div>
          )}

          {loadingItems ? <Spinner /> : items.length === 0 ? (
            <EmptyState variant="list" title="Lista vazia" text="Adicione itens manualmente ou envie os ingredientes que faltam de uma receita." />
          ) : (
            <>
              <p className="text-sm text-muted">{pending} {pending === 1 ? "item pendente" : "itens pendentes"} · {items.length - pending} comprados</p>
              {grouped.map((g) => (
                <section key={g.id}>
                  <h2 className="mb-2 text-lg">{g.emoji} {g.label}</h2>
                  <ul className="space-y-2">
                    {g.items.map((i) => (
                      <li key={i.id} className={cn("card !p-3", i.checked && "opacity-60")}>
                        {editing === i.id ? (
                          <ItemEdit item={i} onCancel={() => setEditing(null)}
                            onSave={(p) => updateItem.mutate({ id: i.id, listId: active.id, ...p }, { onSuccess: () => setEditing(null) })} />
                        ) : (
                          <div className="flex items-center gap-2">
                            <input type="checkbox" className="h-6 w-6 shrink-0 accent-[#1F4E3D]" checked={i.checked} aria-label={`Marcar ${i.name} como comprado`}
                              onChange={(e) => updateItem.mutate({ id: i.id, listId: active.id, checked: e.target.checked })} />
                            <div className="min-w-0 flex-1">
                              <p className={cn("truncate font-medium", i.checked && "line-through")}>{i.name}</p>
                              {i.quantity != null && <p className="text-xs text-muted">{i.quantity} {i.unit ?? ""}</p>}
                            </div>
                            <button className="tap grid place-items-center text-brand" onClick={() => setEditing(i.id)} aria-label={`Editar ${i.name}`}><Pencil className="h-4 w-4" /></button>
                            <button className="tap grid place-items-center text-danger" aria-label={`Remover ${i.name}`}
                              onClick={() => removeItem.mutate({ id: i.id, listId: active.id })}><Trash2 className="h-4 w-4" /></button>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                </section>
              ))}
              {items.some((i) => i.checked) && (
                <Button variant="outline" full onClick={() => {
                  items.filter((i) => i.checked).forEach((i) => removeItem.mutate({ id: i.id, listId: active.id }));
                  toast.success("Itens comprados removidos.");
                }}>Limpar itens comprados</Button>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}

function ItemEdit({ item, onSave, onCancel }: { item: ShoppingItem; onSave: (p: Partial<ShoppingItem>) => void; onCancel: () => void }) {
  const [name, setName] = useState(item.name);
  const [qty, setQty] = useState(item.quantity?.toString() ?? "");
  const [unit, setUnit] = useState(item.unit ?? "un");
  const [cat, setCat] = useState(item.category);
  const q = qty.replace(",", ".");
  const invalid = !name.trim() || (q !== "" && (isNaN(Number(q)) || Number(q) < 0));
  return (
    <div className="space-y-2">
      <input className="input" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} aria-label="Nome" />
      <div className="grid grid-cols-2 gap-2">
        <input className="input" inputMode="decimal" placeholder="Quantidade" value={qty} onChange={(e) => setQty(e.target.value)} aria-label="Quantidade" />
        <select className="input" value={unit} onChange={(e) => setUnit(e.target.value)} aria-label="Unidade">{UNITS.map((u) => <option key={u}>{u}</option>)}</select>
      </div>
      <select className="input" value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Categoria">{CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select>
      <div className="flex gap-2">
        <Button className="flex-1" disabled={invalid} onClick={() => onSave({ name: name.trim(), category: cat, quantity: q === "" ? null : Number(q), unit: q === "" ? null : unit })}><Check className="h-4 w-4" />Salvar</Button>
        <Button variant="outline" className="flex-1" onClick={onCancel}><X className="h-4 w-4" />Cancelar</Button>
      </div>
    </div>
  );
}
