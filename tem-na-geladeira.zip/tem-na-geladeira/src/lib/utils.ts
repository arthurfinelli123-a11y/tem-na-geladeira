import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs));

/** Normaliza texto para comparação: minúsculas, sem acentos e sem pontuação. */
export function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Categorias da despensa. Os ids precisam bater com o CHECK da tabela ingredient_catalog/pantry_items. */
export const CATEGORIES = [
  { id: "carnes", label: "Carnes", emoji: "🥩" },
  { id: "frutas", label: "Frutas", emoji: "🍎" },
  { id: "verduras_legumes", label: "Verduras e legumes", emoji: "🥕" },
  { id: "graos_cereais", label: "Grãos e cereais", emoji: "🌾" },
  { id: "laticinios", label: "Laticínios", emoji: "🧀" },
  { id: "massas_farinhas", label: "Massas e farinhas", emoji: "🍝" },
  { id: "temperos", label: "Temperos", emoji: "🧂" },
  { id: "bebidas", label: "Bebidas", emoji: "🥤" },
  { id: "outros", label: "Outros", emoji: "🧺" },
] as const;

export const categoryLabel = (id: string): string => CATEGORIES.find((c) => c.id === id)?.label ?? "Outros";

export const UNITS = [
  "un",
  "g",
  "kg",
  "ml",
  "l",
  "xícara",
  "colher de sopa",
  "colher de chá",
  "dente",
  "maço",
  "fatia",
  "pitada",
  "lata",
  "pacote",
] as const;
