// Informações EXIBIDAS dos planos. Os limites reais são aplicados no servidor
// (supabase/functions/_shared/http.ts → LIMITS). Se mudar um, mude o outro.

export type PlanId = "free" | "premium" | "familia";

export interface PlanInfo {
  id: PlanId;
  name: string;
  tagline: string;
  features: string[];
}

export const PLAN_INFO: PlanInfo[] = [
  {
    id: "free",
    name: "Free",
    tagline: "Para começar a cozinhar com o que tem em casa.",
    features: [
      "Cadastro gratuito",
      "5 gerações de receitas por dia",
      "Pesquisa manual de ingredientes",
      "Receitas básicas",
      "Favoritos",
      "Lista de compras",
    ],
  },
  {
    id: "premium",
    name: "Premium",
    tagline: "Seu chef pessoal sempre à mão.",
    features: [
      "50 gerações de receitas por dia",
      "Reconhecimento por foto",
      "Chef IA (chat)",
      "Planejamento semanal",
      "Modos especiais de cozinha",
      "Histórico ampliado",
      "Personalização avançada",
    ],
  },
  {
    id: "familia",
    name: "Família",
    tagline: "Tudo do Premium, com limites maiores para a casa toda.",
    features: [
      "Todos os recursos Premium",
      "120 gerações de receitas por dia",
      "Limites maiores de foto, chat e planejamento",
      "Receitas familiares, perfis individuais e planejamento compartilhado: em breve",
    ],
  },
];

/** Textos de preço vêm do ambiente; sem valor, a UI mostra "Em breve" (nada é inventado). */
export const PRICES: Record<PlanId, string | undefined> = {
  free: "Grátis",
  premium: (import.meta.env.VITE_PRICE_PREMIUM as string | undefined) || undefined,
  familia: (import.meta.env.VITE_PRICE_FAMILIA as string | undefined) || undefined,
};

/** Links de checkout do provedor de pagamento (hospedados por ele). Vazio = gateway não configurado. */
export const CHECKOUT_URL: Record<"premium" | "familia", string | undefined> = {
  premium: (import.meta.env.VITE_CHECKOUT_URL_PREMIUM as string | undefined) || undefined,
  familia: (import.meta.env.VITE_CHECKOUT_URL_FAMILIA as string | undefined) || undefined,
};

export interface ComparisonRow {
  label: string;
  free: string | boolean;
  premium: string | boolean;
  familia: string | boolean;
}

export const COMPARISON: ComparisonRow[] = [
  { label: "Gerações de receitas por dia", free: "5", premium: "50", familia: "120" },
  { label: "Pesquisa manual de ingredientes", free: true, premium: true, familia: true },
  { label: "Favoritos e coleções", free: true, premium: true, familia: true },
  { label: "Lista de compras", free: true, premium: true, familia: true },
  { label: "Substituição inteligente", free: "3 por dia", premium: "50 por dia", familia: "120 por dia" },
  { label: "Modos especiais de cozinha", free: false, premium: true, familia: true },
  { label: "Reconhecimento por foto", free: false, premium: "20 por dia", familia: "50 por dia" },
  { label: "Chef IA (chat)", free: false, premium: "150 msgs/dia", familia: "300 msgs/dia" },
  { label: "Planejamento semanal", free: false, premium: "10 por dia", familia: "25 por dia" },
  { label: "Histórico ampliado", free: false, premium: true, familia: true },
  { label: "Receitas familiares compartilhadas", free: false, premium: false, familia: "Em breve" },
  { label: "Perfis individuais", free: false, premium: false, familia: "Em breve" },
];
