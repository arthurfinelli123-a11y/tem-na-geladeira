// Modos especiais de cozinha. Cada modo altera o system prompt no servidor
// (supabase/functions/_shared/prompts.ts → MODE_PROMPTS). Os ids precisam bater com os de lá.

export type ModeId =
  | "economico"
  | "nao_comprar"
  | "improviso"
  | "rapido"
  | "sobremesa"
  | "iniciante"
  | "aproveitamento"
  | "mundial";

export interface ModeDef {
  id: ModeId;
  label: string;
  emoji: string;
  description: string;
  /** Opção extra do modo: lista fechada (free = false) ou texto livre com sugestões (free = true). */
  option?: { label: string; choices: string[]; free?: boolean };
}

export const MODES: ModeDef[] = [
  { id: "economico", label: "Econômico", emoji: "🪙", description: "Receitas acessíveis, sem compras extras." },
  {
    id: "nao_comprar",
    label: "Não quero comprar nada",
    emoji: "🛒",
    description: "Usa SOMENTE ingredientes que você confirmou, incluindo os básicos que declarou ter.",
  },
  { id: "improviso", label: "Improviso", emoji: "🎲", description: "Combinações criativas com o que você tem." },
  {
    id: "rapido",
    label: "Rápido",
    emoji: "⏱️",
    description: "Prontas em 5, 10, 20 ou 30 minutos.",
    option: { label: "Tempo máximo (minutos)", choices: ["5", "10", "20", "30"] },
  },
  { id: "sobremesa", label: "Sobremesa", emoji: "🍰", description: "Bolos, doces, tortas, pudins e biscoitos." },
  { id: "iniciante", label: "Iniciante", emoji: "🎓", description: "Cada etapa explicada em detalhes." },
  {
    id: "aproveitamento",
    label: "Aproveitamento",
    emoji: "♻️",
    description: "Dá novo uso a sobras seguras — nunca recomenda alimentos estragados.",
  },
  {
    id: "mundial",
    label: "Culinária mundial",
    emoji: "🌍",
    description: "Receitas inspiradas em um país ou cultura.",
    option: {
      label: "País ou cultura (ex.: Japão)",
      free: true,
      choices: ["Itália", "Japão", "México", "Índia", "França", "Tailândia", "Líbano", "Espanha", "Marrocos", "Coreia do Sul"],
    },
  },
];

// Ids precisam bater com o enum de generateParamsSchema.mealType
export const MEAL_TYPES = [
  { id: "qualquer", label: "Qualquer" },
  { id: "cafe", label: "Café da manhã" },
  { id: "almoco", label: "Almoço" },
  { id: "jantar", label: "Jantar" },
  { id: "lanche", label: "Lanche" },
  { id: "sobremesa", label: "Sobremesa" },
] as const;

export const DIETS = ["Vegetariano", "Vegano", "Sem glúten", "Sem lactose", "Low carb", "Alta proteína", "Sem açúcar"];

export const EQUIPMENT = [
  "Fogão",
  "Forno",
  "Micro-ondas",
  "Air fryer",
  "Liquidificador",
  "Batedeira",
  "Panela de pressão",
  "Processador",
  "Sanduicheira",
  "Arrozeira",
];
