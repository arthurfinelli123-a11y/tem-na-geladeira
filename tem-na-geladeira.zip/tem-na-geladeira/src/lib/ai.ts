import { z } from "zod";
import { supabase, SUPABASE_URL, isSupabaseConfigured } from "./supabase";
import {
  recipeListSchema, substitutionResultSchema, photoResultSchema, mealPlanSchema,
  type GenerateParams,
} from "./schemas";

/** Erro amigável com código estável para a UI decidir o que mostrar. */
export class AiError extends Error {
  constructor(public code: "not_configured" | "unauthorized" | "limit" | "plan" | "consent" | "empty" | "invalid" | "aborted" | "network" | "unknown",
    message: string) { super(message); }
}

const FRIENDLY: Record<string, string> = {
  not_configured: "A IA ainda não foi configurada neste ambiente. Veja o README (seção “Chaves de IA”).",
  unauthorized: "Sua sessão expirou. Entre novamente para continuar.",
  limit: "Você atingiu o limite de hoje do seu plano. Volte amanhã ou conheça os planos.",
  plan: "Este recurso faz parte do plano Premium.",
  consent: "Autorize o uso dos seus dados pela IA (em Configurações) para continuar.",
  empty: "Não encontrei um resultado para esses dados. Ajuste os ingredientes e tente de novo.",
  invalid: "A IA devolveu um resultado fora do formato esperado. Tente novamente.",
  network: "Não consegui falar com o servidor. Verifique sua conexão.",
  aborted: "Geração cancelada.",
  unknown: "Algo deu errado. Tente novamente em instantes.",
};

async function authHeaders() {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new AiError("unauthorized", FRIENDLY.unauthorized);
  return { "Content-Type": "application/json", Authorization: `Bearer ${token}`, apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string };
}

async function post(fn: string, body: unknown, signal?: AbortSignal): Promise<Response> {
  if (!isSupabaseConfigured) throw new AiError("not_configured", "Supabase não configurado. Veja o README.");
  const headers = await authHeaders();
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, { method: "POST", headers, body: JSON.stringify(body), signal });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      const code = (j?.code as keyof typeof FRIENDLY) ?? (res.status === 401 ? "unauthorized" : res.status === 429 ? "limit" : res.status === 403 ? "plan" : "unknown");
      throw new AiError(code in FRIENDLY ? (code as AiError["code"]) : "unknown", j?.message ?? FRIENDLY[code] ?? FRIENDLY.unknown);
    }
    return res;
  } catch (e) {
    if (e instanceof AiError) throw e;
    if ((e as Error).name === "AbortError") throw new AiError("aborted", FRIENDLY.aborted);
    throw new AiError("network", FRIENDLY.network);
  }
}

async function postJson<S extends z.ZodTypeAny>(fn: string, body: unknown, schema: S, signal?: AbortSignal): Promise<z.infer<S>> {
  const res = await post(fn, body, signal);
  const json = await res.json();
  // Segunda validação no cliente: nada é renderizado sem passar pelo Zod.
  const parsed = schema.safeParse(json);
  if (!parsed.success) throw new AiError("invalid", FRIENDLY.invalid);
  return parsed.data;
}

export const ai = {
  generateRecipes: (params: GenerateParams, signal?: AbortSignal) =>
    postJson("generate-recipes", params, recipeListSchema, signal),
  substitute: (input: { missing: string; recipe: string; available: string[] }, signal?: AbortSignal) =>
    postJson("suggest-substitution", input, substitutionResultSchema, signal),
  analyzePhoto: (input: { imageBase64: string; mediaType: string }, signal?: AbortSignal) =>
    postJson("analyze-photo", input, photoResultSchema, signal),
  planWeek: (input: { days: string[]; meals: string[]; preferences: string; budget: number | null; usePantry: boolean }, signal?: AbortSignal) =>
    postJson("plan-week", input, mealPlanSchema, signal),

  /** Chat com streaming: chama onToken a cada trecho de texto. */
  async chat(input: { conversationId: string; message: string; recipeId?: string | null },
    onToken: (t: string) => void, signal?: AbortSignal): Promise<string> {
    const res = await post("chef-chat", input, signal);
    if (!res.body) throw new AiError("unknown", FRIENDLY.unknown);
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let full = "";
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        full += chunk;
        onToken(chunk);
      }
    } catch (e) {
      if ((e as Error).name === "AbortError") throw new AiError("aborted", FRIENDLY.aborted);
      throw new AiError("network", FRIENDLY.network);
    }
    return full;
  },
};

export function friendlyError(e: unknown): string {
  if (e instanceof AiError) return e.message;
  return FRIENDLY.unknown;
}
