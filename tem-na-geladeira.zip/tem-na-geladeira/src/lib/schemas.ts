// Mesmos schemas das Edge Functions (supabase/functions/_shared/schemas.ts, versão Deno).
// Mantenha os dois em sincronia: a IA é validada no servidor E de novo aqui, antes de renderizar.
import { z } from "zod";

export const recipeIngredientSchema = z.object({
  name: z.string().min(1),
  quantity: z.number().nonnegative().nullable().optional(),
  unit: z.string().nullable().optional(),
  have: z.boolean(),
  essential: z.boolean().default(true),
});
export type RecipeIngredient = z.infer<typeof recipeIngredientSchema>;

export const recipeSchema = z.object({
  title: z.string().min(2),
  description: z.string().min(2),
  emoji: z.string().default("🍽️"),
  category: z.string().default("geral"),
  ingredients: z.array(recipeIngredientSchema).min(1),
  prep_minutes: z.number().int().nonnegative(),
  cook_minutes: z.number().int().nonnegative(),
  difficulty: z.enum(["facil", "medio", "dificil"]),
  servings: z.number().int().positive(),
  steps: z.array(z.object({ title: z.string().optional(), text: z.string().min(2) })).min(1),
  tips: z.array(z.string()).default([]),
  substitutions: z
    .array(z.object({ missing: z.string(), alternative: z.string(), note: z.string().optional() }))
    .default([]),
  compatibility: z.enum(["completa", "requer_adicional"]),
  missing_essentials: z.array(z.string()).default([]),
  allergen_warnings: z.array(z.string()).default([]),
  cross_contamination: z.array(z.string()).default([]),
  safety_notes: z.array(z.string()).default([]),
  nutrition: z
    .object({
      calories: z.number().nullable().optional(),
      protein_g: z.number().nullable().optional(),
      carbs_g: z.number().nullable().optional(),
      fat_g: z.number().nullable().optional(),
      approximate: z.literal(true),
    })
    .nullable()
    .optional(),
});
export type Recipe = z.infer<typeof recipeSchema>;

export const recipeListSchema = z.object({ recipes: z.array(recipeSchema).min(1) });

export const substitutionResultSchema = z.object({
  ideal: z.string(),
  quantity: z.string(),
  texture_impact: z.string(),
  flavor_impact: z.string(),
  verdict: z.enum(["funciona", "ressalvas", "nao_recomendado"]),
  notes: z.string().optional(),
});
export type SubstitutionResult = z.infer<typeof substitutionResultSchema>;

export const photoResultSchema = z.object({
  items: z.array(
    z.object({
      name: z.string(),
      category: z.string().default("outros"),
      confidence: z.enum(["alta", "media", "baixa"]).default("media"),
    }),
  ),
});

export const mealPlanSchema = z.object({
  days: z.array(
    z.object({
      day: z.string(),
      meals: z.array(
        z.object({
          meal: z.string(),
          title: z.string(),
          description: z.string(),
          uses_from_pantry: z.array(z.string()).default([]),
          to_buy: z.array(z.string()).default([]),
        }),
      ),
    }),
  ),
  shopping_list: z.array(
    z.object({
      name: z.string(),
      quantity: z.number().nullable().optional(),
      unit: z.string().nullable().optional(),
      category: z.string().default("outros"),
    }),
  ),
  estimated_note: z.string().optional(),
});
export type MealPlan = z.infer<typeof mealPlanSchema>;

export const generateParamsSchema = z.object({
  mealType: z.enum(["qualquer", "cafe", "almoco", "jantar", "lanche", "sobremesa"]).default("qualquer"),
  servings: z.number().int().min(1).max(20).default(2),
  maxMinutes: z.number().int().min(5).max(240).nullable().default(null),
  difficulty: z.enum(["qualquer", "facil", "medio", "dificil"]).default("qualquer"),
  mode: z.string().nullable().default(null),
  modeOption: z.string().nullable().default(null),
  equipment: z.array(z.string()).default([]),
});
export type GenerateParams = z.infer<typeof generateParamsSchema>;
