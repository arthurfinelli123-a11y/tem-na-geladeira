import type { Recipe } from "./schemas";

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  diet_preferences: string[];
  allergies: string[];
  default_servings: number;
  favorite_ingredients: string[];
  disliked_ingredients: string[];
  equipment: string[];
  ai_consent: boolean;
}

export interface PantryItem {
  id: string;
  user_id: string;
  name: string;
  category: string;
  quantity: number | null;
  unit: string | null;
  excluded: boolean;
}

export interface CatalogItem { id: number; name: string; category: string }

export interface SavedRecipe {
  id: string;
  user_id: string;
  title: string;
  category: string;
  mode: string | null;
  data: Recipe;
  is_public: boolean;
  share_slug: string | null;
  created_at: string;
}

export interface Collection { id: string; name: string; created_at: string }
export interface ShoppingList { id: string; name: string; archived: boolean; created_at: string }
export interface ShoppingItem {
  id: string; list_id: string; name: string; quantity: number | null; unit: string | null;
  category: string; checked: boolean; source_recipe_id: string | null;
}
export interface Conversation { id: string; title: string; recipe_id: string | null; updated_at: string }
export interface ChatMessage { id: string; conversation_id: string; role: "user" | "assistant"; content: string; created_at: string }

export interface Subscription {
  plan: "free" | "premium" | "familia";
  status: "inactive" | "active" | "past_due" | "canceled";
  provider: string | null;
  current_period_end: string | null;
}
export interface UsageRow { kind: string; count: number }
