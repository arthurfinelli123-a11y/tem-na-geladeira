import { useMemo, useRef, useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { useCatalog } from "@/hooks/data";
import { normalize } from "@/lib/utils";

/** Campo com autocomplete (dataset seed `ingredient_catalog`). Aceita também itens livres. */
export function IngredientInput({ onAdd, placeholder = "Ex.: arroz, ovo, tomate…", autoFocus }: {
  onAdd: (name: string, category: string) => void; placeholder?: string; autoFocus?: boolean;
}) {
  const { data: catalog = [] } = useCatalog();
  const [value, setValue] = useState("");
  const [focus, setFocus] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  const suggestions = useMemo(() => {
    const q = normalize(value);
    if (q.length < 1) return [];
    return catalog.filter((c) => normalize(c.name).includes(q)).slice(0, 6);
  }, [value, catalog]);

  function commit(name: string) {
    const clean = name.trim().replace(/\s+/g, " ");
    if (!clean) return;
    const hit = catalog.find((c) => normalize(c.name) === normalize(clean));
    onAdd(hit?.name ?? clean.charAt(0).toUpperCase() + clean.slice(1), hit?.category ?? "outros");
    setValue("");
    ref.current?.focus();
  }

  return (
    <div className="relative">
      <div className="flex gap-2">
        <input
          ref={ref} value={value} autoFocus={autoFocus} maxLength={80}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => setFocus(true)} onBlur={() => setTimeout(() => setFocus(false), 150)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === ",") { e.preventDefault(); commit(value); }
          }}
          className="input" placeholder={placeholder} aria-label="Adicionar ingrediente" enterKeyHint="done"
        />
        <Button type="button" onClick={() => commit(value)} aria-label="Adicionar" className="px-4"><Plus className="h-5 w-5" /></Button>
      </div>
      {focus && suggestions.length > 0 && (
        <ul className="absolute z-20 mt-1 w-full overflow-hidden rounded-2xl border border-brand/10 bg-white shadow-lift" role="listbox">
          {suggestions.map((s) => (
            <li key={s.id}>
              <button type="button" role="option" aria-selected={false} onMouseDown={(e) => e.preventDefault()} onClick={() => commit(s.name)}
                className="tap flex w-full items-center justify-between px-4 text-left text-sm hover:bg-brand-soft">
                {s.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
