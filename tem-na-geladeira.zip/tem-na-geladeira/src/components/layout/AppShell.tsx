import { useState, type ReactNode } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  Home, Refrigerator, Sparkles, MessageCircle, BookHeart, Menu, X, Camera, Wand2, Shuffle,
  CalendarDays, ShoppingCart, User, Crown, Settings, LogOut, LayoutDashboard, ShieldCheck, FileText,
} from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/ui/Logo";
import { Button } from "@/components/ui/Button";
import { useAuth } from "@/store/auth";
import { supabase } from "@/lib/supabase";
import { cn } from "@/lib/utils";

const BOTTOM = [
  { to: "/painel", label: "Painel", icon: LayoutDashboard },
  { to: "/ingredientes", label: "Despensa", icon: Refrigerator },
  { to: "/gerar", label: "Gerar", icon: Sparkles, highlight: true },
  { to: "/chef-ia", label: "Chef IA", icon: MessageCircle },
  { to: "/minhas-receitas", label: "Receitas", icon: BookHeart },
];

const MENU = [
  { to: "/foto", label: "Reconhecer por foto", icon: Camera },
  { to: "/modos", label: "Modos de cozinha", icon: Wand2 },
  { to: "/substituicao", label: "Substituição inteligente", icon: Shuffle },
  { to: "/planejamento", label: "Planejamento semanal", icon: CalendarDays },
  { to: "/lista-compras", label: "Lista de compras", icon: ShoppingCart },
  { to: "/perfil", label: "Meu perfil", icon: User },
  { to: "/planos", label: "Planos", icon: Crown },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
  { to: "/privacidade", label: "Privacidade", icon: ShieldCheck },
  { to: "/termos", label: "Termos de uso", icon: FileText },
];

export function AppShell({ children }: { children: ReactNode }) {
  const user = useAuth((s) => s.user);
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const loc = useLocation();

  async function logout() {
    await supabase.auth.signOut();
    setOpen(false);
    toast.success("Você saiu da conta.");
    nav("/");
  }

  return (
    <div className={cn("min-h-screen", user && "has-bottom-nav")}>
      <header className="sticky top-0 z-30 border-b border-brand/10 bg-cream/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4">
          <Link to={user ? "/painel" : "/"} aria-label="Tem na Geladeira — início"><Logo size={32} withText /></Link>

          {/* Navegação desktop / visitante */}
          <nav className="hidden items-center gap-1 md:flex" aria-label="Principal">
            {(user ? BOTTOM : [{ to: "/planos", label: "Planos" }, { to: "/#como-funciona", label: "Como funciona" }]).map((l) => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) =>
                cn("tap flex items-center rounded-xl px-3 text-sm font-medium text-brand hover:bg-brand-soft", isActive && "bg-brand-soft")}>
                {l.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {!user && (
              <>
                <Link to="/login" className="tap hidden items-center px-3 text-sm font-semibold text-brand sm:flex">Entrar</Link>
                <Link to="/cadastro"><Button variant="cta" className="!min-h-[40px] px-4 text-sm">Criar conta</Button></Link>
              </>
            )}
            <button className="tap grid place-items-center rounded-xl text-brand hover:bg-brand-soft" onClick={() => setOpen(true)} aria-label="Abrir menu">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence mode="wait">
        <motion.main
          key={loc.pathname}
          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22 }}
          className="mx-auto max-w-5xl px-4 py-5"
        >
          {children}
        </motion.main>
      </AnimatePresence>

      {user && (
        <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-brand/10 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden" aria-label="Navegação inferior">
          <ul className="mx-auto grid max-w-md grid-cols-5">
            {BOTTOM.map(({ to, label, icon: Icon, highlight }) => (
              <li key={to}>
                <NavLink to={to} className={({ isActive }) =>
                  cn("tap flex h-16 flex-col items-center justify-center gap-0.5 text-[11px] font-medium text-muted", isActive && "text-brand")}>
                  {({ isActive }) => (
                    <>
                      <span className={cn("grid h-8 w-8 place-items-center rounded-full transition-colors",
                        highlight && "bg-accent text-ink", !highlight && isActive && "bg-brand-soft")}>
                        <Icon className="h-5 w-5" />
                      </span>
                      {label}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <AnimatePresence>
        {open && (
          <>
            <motion.div className="fixed inset-0 z-40 bg-ink/40" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} />
            <motion.aside
              role="dialog" aria-label="Menu"
              className="fixed right-0 top-0 z-50 flex h-full w-[84%] max-w-sm flex-col rounded-l-3xl bg-cream p-4 shadow-lift"
              initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ duration: 0.25 }}
            >
              <div className="mb-3 flex items-center justify-between">
                <Logo size={30} withText />
                <button className="tap grid place-items-center rounded-xl hover:bg-brand-soft" onClick={() => setOpen(false)} aria-label="Fechar menu"><X /></button>
              </div>
              <ul className="flex-1 space-y-1 overflow-y-auto">
                {user ? MENU.map(({ to, label, icon: Icon }) => (
                  <li key={to}>
                    <Link to={to} onClick={() => setOpen(false)} className="tap flex items-center gap-3 rounded-2xl px-3 text-base font-medium text-brand hover:bg-brand-soft">
                      <Icon className="h-5 w-5" />{label}
                    </Link>
                  </li>
                )) : (
                  [{ to: "/", label: "Início", icon: Home }, { to: "/planos", label: "Planos", icon: Crown },
                   { to: "/privacidade", label: "Privacidade", icon: ShieldCheck }, { to: "/termos", label: "Termos de uso", icon: FileText }]
                    .map(({ to, label, icon: Icon }) => (
                      <li key={to}>
                        <Link to={to} onClick={() => setOpen(false)} className="tap flex items-center gap-3 rounded-2xl px-3 text-base font-medium text-brand hover:bg-brand-soft">
                          <Icon className="h-5 w-5" />{label}
                        </Link>
                      </li>
                    ))
                )}
              </ul>
              {user ? (
                <Button variant="outline" full onClick={logout}><LogOut className="h-4 w-4" />Sair</Button>
              ) : (
                <div className="grid gap-2">
                  <Link to="/login" onClick={() => setOpen(false)}><Button variant="outline" full>Entrar</Button></Link>
                  <Link to="/cadastro" onClick={() => setOpen(false)}><Button variant="cta" full>Criar conta grátis</Button></Link>
                </div>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <footer className={cn("mx-auto max-w-5xl px-4 pb-8 text-center text-xs text-muted", user && "hidden md:block")}>
        <p>Sua cozinha tem os ingredientes. Nossa IA tem as ideias.</p>
        <p className="mt-1">
          <Link to="/privacidade" className="underline">Privacidade</Link> · <Link to="/termos" className="underline">Termos</Link> · <Link to="/planos" className="underline">Planos</Link>
        </p>
      </footer>
    </div>
  );
}
