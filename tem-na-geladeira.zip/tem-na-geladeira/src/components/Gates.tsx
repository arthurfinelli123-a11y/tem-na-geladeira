import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Crown, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { NotConfigured, Spinner } from "@/components/ui/States";
import { isSupabaseConfigured } from "@/lib/supabase";
import { useEffectivePlan, useProfile, useSaveProfile } from "@/hooks/data";

/** Pede consentimento explícito antes de enviar dados do usuário à IA (e bloqueia se o backend não existe). */
export function AiGate({ children }: { children: ReactNode }) {
  const { data: profile, isLoading } = useProfile();
  const save = useSaveProfile(true);

  if (!isSupabaseConfigured) {
    return <NotConfigured what="Supabase" how="Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no arquivo .env (veja o README)." />;
  }
  if (isLoading) return <Spinner />;
  if (!profile?.ai_consent) {
    return (
      <div className="card space-y-3">
        <div className="flex items-center gap-2 text-brand"><ShieldCheck className="h-5 w-5" /><h2 className="text-lg">Antes de usar a IA</h2></div>
        <p className="text-sm text-muted">
          Para criar receitas, enviaremos à IA a sua lista de ingredientes, suas preferências e restrições alimentares.
          Seus dados são usados somente para isso e você pode revogar a permissão a qualquer momento em Configurações.
        </p>
        <Button variant="cta" full loading={save.isPending} onClick={() => save.mutate({ ai_consent: true })}>
          Autorizo o uso dos meus dados pela IA
        </Button>
        <p className="text-xs text-muted">Veja a <Link className="underline" to="/privacidade">Política de privacidade</Link>.</p>
      </div>
    );
  }
  return <>{children}</>;
}

/** Bloqueia recursos Premium com um convite claro de upgrade. */
export function PremiumGate({ feature, children }: { feature: string; children: ReactNode }) {
  const plan = useEffectivePlan();
  const { isLoading } = useProfile();
  if (isLoading) return <Spinner />;
  if (plan === "free") {
    return (
      <div className="card space-y-3 text-center">
        <Crown className="mx-auto h-8 w-8 text-accent-dark" />
        <h2 className="text-lg">{feature} é um recurso Premium</h2>
        <p className="text-sm text-muted">Conheça o plano Premium para liberar este e outros recursos.</p>
        <Link to="/planos"><Button variant="cta" full>Ver planos</Button></Link>
      </div>
    );
  }
  return <>{children}</>;
}
