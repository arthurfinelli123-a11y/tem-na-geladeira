import { useEffect, useRef } from "react";
import { useAuth } from "@/store/auth";
import { useDraft } from "@/store/draft";
import { useAddPantry } from "@/hooks/data";
import { toast } from "sonner";

/** Ao entrar, move para a despensa os ingredientes que o visitante digitou na Home. */
export function DraftImporter() {
  const user = useAuth((s) => s.user);
  const { guestIngredients, clearGuest } = useDraft();
  const add = useAddPantry();
  const done = useRef(false);

  useEffect(() => {
    if (!user || done.current || guestIngredients.length === 0) return;
    done.current = true;
    add.mutate(guestIngredients.map((name) => ({ name })), {
      onSuccess: () => { clearGuest(); toast.success("Ingredientes da Home salvos na sua despensa."); },
      onSettled: () => { done.current = false; },
    });
  }, [user, guestIngredients, add, clearGuest]);

  return null;
}
