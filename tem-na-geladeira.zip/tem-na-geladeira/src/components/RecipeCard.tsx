import { Link } from "react-router-dom";
import { Clock, Heart, ChefHat, AlertTriangle, CheckCircle2 } from "lucide-react";
import type { Recipe } from "@/lib/schemas";
import { cn } from "@/lib/utils";

export const DIFFICULTY: Record<Recipe["difficulty"], string> = { facil: "Fácil", medio: "Médio", dificil: "Difícil" };

export function CompatBadge({ r }: { r: Recipe }) {
  return r.compatibility === "completa" ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-brand-soft px-2.5 py-1 text-xs font-semibold text-brand">
      <CheckCircle2 className="h-3.5 w-3.5" />Com o que você tem
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-accent/20 px-2.5 py-1 text-xs font-semibold text-ink">
      <AlertTriangle className="h-3.5 w-3.5" />Requer ingrediente adicional
    </span>
  );
}

/** Ilustração do prato: emoji sobre fundo de marca. É ilustrativa — não é foto real do prato. */
export function RecipeArt({ emoji, className }: { emoji: string; className?: string }) {
  return (
    <div className={cn("grid place-items-center rounded-2xl bg-gradient-to-br from-brand-soft to-brand-light/60", className)} role="img" aria-label="Ilustração do prato">
      <span className="text-5xl" aria-hidden>{emoji || "🍽️"}</span>
    </div>
  );
}

export function RecipeCard({ id, recipe, favorite, onToggleFavorite }: {
  id: string; recipe: Recipe; favorite?: boolean; onToggleFavorite?: () => void;
}) {
  const total = recipe.prep_minutes + recipe.cook_minutes;
  return (
    <article className="card relative !p-3">
      <Link to={`/receita/${id}`} className="flex gap-3">
        <RecipeArt emoji={recipe.emoji} className="h-24 w-24 shrink-0" />
        <div className="min-w-0 flex-1 space-y-1.5">
          <h3 className="line-clamp-2 pr-10 text-lg leading-snug">{recipe.title}</h3>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
            <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{total} min</span>
            <span className="inline-flex items-center gap-1"><ChefHat className="h-3.5 w-3.5" />{DIFFICULTY[recipe.difficulty]}</span>
          </div>
          <CompatBadge r={recipe} />
        </div>
      </Link>
      {onToggleFavorite && (
        <button onClick={onToggleFavorite} aria-label={favorite ? "Remover dos favoritos" : "Favoritar"} aria-pressed={favorite}
          className="tap absolute right-2 top-2 grid place-items-center rounded-full hover:bg-brand-soft">
          <Heart className={cn("h-5 w-5", favorite ? "fill-accent text-accent" : "text-muted")} />
        </button>
      )}
    </article>
  );
}
