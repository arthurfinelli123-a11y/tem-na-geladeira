export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden>
      <rect x="8" y="4" width="48" height="56" rx="14" fill="#1F4E3D" />
      <rect x="14" y="10" width="36" height="20" rx="8" fill="#A8D5BA" />
      <rect x="14" y="34" width="36" height="20" rx="8" fill="#FAF6EF" />
      <rect x="42" y="16" width="3" height="8" rx="1.5" fill="#1F4E3D" />
      <rect x="42" y="40" width="3" height="8" rx="1.5" fill="#1F4E3D" />
      <path d="M26 44c0-5 4-8 8-8 0 5-3 9-8 8z" fill="#F59E5B" />
    </svg>
  );
}

export function Logo({ size = 36, withText = false }: { size?: number; withText?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <LogoMark size={size} />
      {withText && (
        <span className="font-display text-xl font-bold leading-none text-brand">
          Tem na <span className="text-accent-dark">Geladeira</span>
        </span>
      )}
    </span>
  );
}
