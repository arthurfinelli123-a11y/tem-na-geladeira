import type { ReactNode } from "react";
import { AlertTriangle, Settings2 } from "lucide-react";
import { Logo } from "@/components/ui/Logo";

/** Tela de loading de tela cheia. */
export function LoadingScreen({ label = "Preparando sua cozinha…" }: { label?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-cream">
      <div className="animate-pulse"><Logo size={56} /></div>
      <p className="text-sm text-muted">{label}</p>
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-10 text-muted" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-brand/20 border-t-brand" />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}

/** Estado vazio ilustrado (SVG próprio). */
export function EmptyState({ title, text, action, variant = "pantry" }: {
  title: string; text?: string; action?: ReactNode; variant?: "pantry" | "recipes" | "chat" | "list" | "generic";
}) {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-10 text-center">
      <svg width="120" height="104" viewBox="0 0 120 104" aria-hidden>
        <ellipse cx="60" cy="96" rx="40" ry="6" fill="#A8D5BA" opacity=".35" />
        <rect x="30" y="8" width="60" height="84" rx="16" fill="#1F4E3D" />
        <rect x="36" y="14" width="48" height="30" rx="10" fill="#A8D5BA" />
        <rect x="36" y="48" width="48" height="38" rx="10" fill="#FAF6EF" />
        <rect x="74" y="22" width="4" height="12" rx="2" fill="#1F4E3D" />
        <rect x="74" y="58" width="4" height="12" rx="2" fill="#1F4E3D" />
        {variant === "pantry" && <circle cx="52" cy="68" r="8" fill="#F59E5B" />}
        {variant === "recipes" && <path d="M46 70c0-8 6-13 14-13 0 8-6 14-14 13z" fill="#F59E5B" />}
        {variant === "chat" && <rect x="46" y="60" width="26" height="14" rx="7" fill="#F59E5B" />}
        {variant === "list" && <rect x="48" y="58" width="24" height="4" rx="2" fill="#F59E5B" />}
        {variant === "generic" && <circle cx="60" cy="68" r="6" fill="#F59E5B" />}
      </svg>
      <h3 className="text-lg">{title}</h3>
      {text && <p className="max-w-xs text-sm text-muted">{text}</p>}
      {action}
    </div>
  );
}

/** Mensagem de erro amigável. */
export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex items-start gap-3 rounded-2xl border border-danger/25 bg-danger/5 p-4 text-sm text-danger">
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
      <div className="flex-1">
        <p>{message}</p>
        {onRetry && (
          <button onClick={onRetry} className="tap mt-1 font-semibold underline underline-offset-2">Tentar de novo</button>
        )}
      </div>
    </div>
  );
}

/** Estado claro de "não configurado" para integrações pendentes. */
export function NotConfigured({ what, how }: { what: string; how: string }) {
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-accent/40 bg-accent/10 p-4 text-sm text-ink">
      <Settings2 className="mt-0.5 h-5 w-5 shrink-0 text-accent-dark" aria-hidden />
      <div>
        <p className="font-semibold">{what} não configurado</p>
        <p className="mt-0.5 text-muted">{how}</p>
      </div>
    </div>
  );
}

/** Aviso fixo de segurança alimentar. */
export function SafetyNotice({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2 rounded-2xl bg-brand-soft p-3 text-xs text-brand">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      <p>{children}</p>
    </div>
  );
}
