import { forwardRef, type ButtonHTMLAttributes } from "react";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "cta" | "ghost" | "outline" | "danger";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
  full?: boolean;
}

const styles: Record<Variant, string> = {
  primary: "bg-brand text-white hover:bg-brand-dark",
  cta: "bg-accent text-ink hover:bg-accent-dark",
  ghost: "bg-transparent text-brand hover:bg-brand-soft",
  outline: "border border-brand/25 bg-white text-brand hover:bg-brand-soft",
  danger: "bg-white text-danger border border-danger/30 hover:bg-danger/5",
};

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = "primary", loading, full, className, children, disabled, ...rest }, ref,
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        "tap inline-flex items-center justify-center gap-2 rounded-2xl px-5 text-base font-semibold",
        "transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-60",
        styles[variant], full && "w-full", className,
      )}
      {...rest}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
});
