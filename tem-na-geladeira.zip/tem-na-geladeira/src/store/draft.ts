import { create } from "zustand";
import { persist } from "zustand/middleware";

/** Ingredientes digitados na Home por visitantes ainda sem conta (ficam só no aparelho). */
interface DraftState {
  guestIngredients: string[];
  addGuest: (name: string) => void;
  removeGuest: (name: string) => void;
  clearGuest: () => void;
}

export const useDraft = create<DraftState>()(
  persist(
    (set) => ({
      guestIngredients: [],
      addGuest: (name) =>
        set((s) =>
          s.guestIngredients.some((i) => i.toLowerCase() === name.toLowerCase())
            ? s
            : { guestIngredients: [...s.guestIngredients, name] },
        ),
      removeGuest: (name) => set((s) => ({ guestIngredients: s.guestIngredients.filter((i) => i !== name) })),
      clearGuest: () => set({ guestIngredients: [] }),
    }),
    { name: "tng-draft" },
  ),
);
