import { create } from "zustand";
import type { Session, User } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

interface AuthState {
  session: Session | null;
  user: User | null;
  loading: boolean;
  init: () => () => void;
}

export const useAuth = create<AuthState>((set) => ({
  session: null,
  user: null,
  loading: true,
  init: () => {
    if (!isSupabaseConfigured) {
      set({ loading: false });
      return () => {};
    }
    supabase.auth.getSession().then(({ data }) =>
      set({ session: data.session, user: data.session?.user ?? null, loading: false }),
    );
    const { data } = supabase.auth.onAuthStateChange((_e, session) =>
      set({ session, user: session?.user ?? null, loading: false }),
    );
    return () => data.subscription.unsubscribe();
  },
}));
