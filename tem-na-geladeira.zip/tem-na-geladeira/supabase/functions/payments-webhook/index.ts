// Webhook do gateway de pagamento (implementado para Stripe; adapte o parser para outro provedor).
// É a ÚNICA forma de uma assinatura passar a "active": só depois da confirmação assinada do provedor.
// Deploy: supabase functions deploy payments-webhook --no-verify-jwt
//
// Secrets: STRIPE_WEBHOOK_SECRET, STRIPE_PRICE_PREMIUM, STRIPE_PRICE_FAMILIA
// Eventos a habilitar no Stripe: checkout.session.completed, customer.subscription.created,
// customer.subscription.updated, customer.subscription.deleted
import { admin } from "../_shared/http.ts";

const enc = new TextEncoder();

async function verifyStripe(body: string, header: string | null, secret: string): Promise<boolean> {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]));
  const t = parts["t"], v1 = parts["v1"];
  if (!t || !v1) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > 300) return false; // anti-replay (5 min)
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(`${t}.${body}`));
  const hex = [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  // comparação em tempo constante
  if (hex.length !== v1.length) return false;
  let diff = 0;
  for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ v1.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const secret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
  if (!secret) return new Response("Webhook não configurado (STRIPE_WEBHOOK_SECRET).", { status: 503 });

  const body = await req.text();
  if (!(await verifyStripe(body, req.headers.get("stripe-signature"), secret))) {
    return new Response("Assinatura inválida", { status: 400 });
  }

  const event = JSON.parse(body);
  const db = admin();
  const obj = event.data?.object ?? {};

  try {
    if (event.type === "checkout.session.completed") {
      // Apenas vincula cliente/assinatura ao usuário. NÃO ativa o plano aqui.
      const uid: string | undefined = obj.client_reference_id;
      if (uid) {
        await db.from("subscriptions").update({
          provider: "stripe", provider_customer_id: obj.customer, provider_subscription_id: obj.subscription,
          updated_at: new Date().toISOString(),
        }).eq("user_id", uid);
      }
    } else if (event.type?.startsWith("customer.subscription.")) {
      const priceId: string | undefined = obj.items?.data?.[0]?.price?.id;
      const plan = priceId && priceId === Deno.env.get("STRIPE_PRICE_FAMILIA") ? "familia"
        : priceId && priceId === Deno.env.get("STRIPE_PRICE_PREMIUM") ? "premium" : null;
      const status = event.type === "customer.subscription.deleted" ? "canceled"
        : ["active", "trialing"].includes(obj.status) ? "active"
        : obj.status === "past_due" ? "past_due" : "canceled";
      if (plan) {
        await db.from("subscriptions").update({
          plan, status, provider: "stripe", provider_subscription_id: obj.id,
          current_period_end: obj.current_period_end ? new Date(obj.current_period_end * 1000).toISOString() : null,
          updated_at: new Date().toISOString(),
        }).eq("provider_customer_id", obj.customer);
      } else {
        console.warn("Price ID desconhecido; configure STRIPE_PRICE_PREMIUM/FAMILIA:", priceId);
      }
    }
    return new Response(JSON.stringify({ received: true }), { headers: { "Content-Type": "application/json" } });
  } catch (e) {
    console.error("Erro no webhook:", e);
    return new Response("Erro ao processar", { status: 500 });
  }
});
