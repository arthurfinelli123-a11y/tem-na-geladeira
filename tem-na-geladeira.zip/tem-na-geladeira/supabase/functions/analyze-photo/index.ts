import { corsHeaders, json, errorResponse, requireUser, requireConsent, getPlan, consumeUsage, HttpError } from "../_shared/http.ts";
import { completeText, extractJson, getConfig } from "../_shared/llm.ts";
import { PHOTO_SYSTEM } from "../_shared/prompts.ts";
import { photoResultSchema } from "../_shared/schemas.ts";

const ALLOWED = ["image/jpeg", "image/png", "image/webp"];
const MAX_BASE64 = 7_000_000; // ~5 MB de imagem

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { user, db } = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const imageBase64 = String(body.imageBase64 ?? "");
    const mediaType = String(body.mediaType ?? "");
    if (!ALLOWED.includes(mediaType)) throw new HttpError(400, "invalid", "Formato de imagem não suportado. Use JPG, PNG ou WebP.");
    if (!imageBase64 || imageBase64.length > MAX_BASE64) throw new HttpError(400, "invalid", "Imagem vazia ou grande demais.");

    await requireConsent(db, user.id);
    const plan = await getPlan(db, user.id);
    getConfig();
    const refund = await consumeUsage(db, user.id, "photo", plan); // free = 0 → exige Premium

    try {
      const text = await completeText({
        system: PHOTO_SYSTEM,
        messages: [{ role: "user", content: "Liste os ingredientes visíveis nesta imagem." }],
        image: { base64: imageBase64, mediaType }, json: true, maxTokens: 2000,
      });
      const parsed = photoResultSchema.safeParse(extractJson(text));
      if (!parsed.success) throw new HttpError(502, "invalid", "Não consegui interpretar a imagem. Tente outra foto.");

      const seen = new Set<string>();
      const items = parsed.data.items.filter((i) => {
        const k = i.name.trim().toLowerCase();
        if (!k || seen.has(k)) return false;
        seen.add(k); return true;
      });
      return json({ items });
    } catch (e) {
      await refund();
      throw e;
    }
  } catch (e) {
    return errorResponse(e);
  }
});
