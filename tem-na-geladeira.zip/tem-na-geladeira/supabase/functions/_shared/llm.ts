// Camada única de IA: texto (LLM) + imagem (Vision) + streaming.
// As chaves vivem SOMENTE aqui, nos secrets do Supabase. Nunca no frontend.
//
// Secrets (supabase secrets set ...):
//   LLM_PROVIDER      "anthropic" (padrão) ou "openai" (qualquer API compatível com /chat/completions)
//   LLM_API_KEY       chave do provedor            <-- OBRIGATÓRIA
//   LLM_MODEL         modelo de texto (padrão anthropic: claude-sonnet-5-5 | openai: gpt-4o-mini)
//   LLM_VISION_MODEL  modelo com visão (padrão: o mesmo de LLM_MODEL)
//   LLM_BASE_URL      opcional (provedores compatíveis com OpenAI)
import { HttpError } from "./http.ts";

type Provider = "anthropic" | "openai";
interface Config { provider: Provider; key: string; model: string; visionModel: string; baseUrl: string }

export function getConfig(): Config {
  const key = Deno.env.get("LLM_API_KEY");
  if (!key) {
    throw new HttpError(503, "not_configured",
      "A IA ainda não foi configurada. Defina o secret LLM_API_KEY (veja o README).");
  }
  const provider = (Deno.env.get("LLM_PROVIDER") ?? "anthropic") as Provider;
  const model = Deno.env.get("LLM_MODEL") ?? (provider === "anthropic" ? "claude-sonnet-5-5" : "gpt-4o-mini");
  return {
    provider, key, model,
    visionModel: Deno.env.get("LLM_VISION_MODEL") ?? model,
    baseUrl: Deno.env.get("LLM_BASE_URL") ?? (provider === "anthropic" ? "https://api.anthropic.com" : "https://api.openai.com/v1"),
  };
}

export type Msg = { role: "user" | "assistant"; content: string };

function anthropicHeaders(c: Config) {
  return { "x-api-key": c.key, "anthropic-version": "2023-06-01", "content-type": "application/json" };
}
function openaiHeaders(c: Config) {
  return { Authorization: `Bearer ${c.key}`, "content-type": "application/json" };
}

async function failIfBad(res: Response) {
  if (res.ok) return;
  const body = await res.text().catch(() => "");
  console.error("Falha do provedor de IA:", res.status, body.slice(0, 500));
  if (res.status === 401 || res.status === 403) {
    throw new HttpError(503, "not_configured", "A chave de IA configurada é inválida.");
  }
  if (res.status === 429) throw new HttpError(503, "unknown", "O provedor de IA está sobrecarregado. Tente novamente em instantes.");
  throw new HttpError(502, "unknown", "A IA não respondeu como esperado. Tente novamente.");
}

/** Resposta completa em texto. `image` ativa o modo Vision. */
export async function completeText(opts: {
  system: string; messages: Msg[]; maxTokens?: number; json?: boolean;
  image?: { base64: string; mediaType: string }; signal?: AbortSignal;
}): Promise<string> {
  const c = getConfig();
  const maxTokens = opts.maxTokens ?? 4096;
  const model = opts.image ? c.visionModel : c.model;

  if (c.provider === "anthropic") {
    const messages = opts.messages.map((m, i) => {
      const isLastUser = opts.image && i === opts.messages.length - 1 && m.role === "user";
      return isLastUser
        ? { role: m.role, content: [
            { type: "image", source: { type: "base64", media_type: opts.image!.mediaType, data: opts.image!.base64 } },
            { type: "text", text: m.content } ] }
        : m;
    });
    const res = await fetch(`${c.baseUrl}/v1/messages`, {
      method: "POST", headers: anthropicHeaders(c), signal: opts.signal,
      body: JSON.stringify({ model, max_tokens: maxTokens, system: opts.system, messages }),
    });
    await failIfBad(res);
    const j = await res.json();
    return (j.content ?? []).map((b: { text?: string }) => b.text ?? "").join("");
  }

  const messages = [
    { role: "system", content: opts.system },
    ...opts.messages.map((m, i) => {
      const isLastUser = opts.image && i === opts.messages.length - 1 && m.role === "user";
      return isLastUser
        ? { role: m.role, content: [
            { type: "text", text: m.content },
            { type: "image_url", image_url: { url: `data:${opts.image!.mediaType};base64,${opts.image!.base64}` } } ] }
        : m;
    }),
  ];
  const res = await fetch(`${c.baseUrl}/chat/completions`, {
    method: "POST", headers: openaiHeaders(c), signal: opts.signal,
    body: JSON.stringify({ model, max_tokens: maxTokens, messages, ...(opts.json ? { response_format: { type: "json_object" } } : {}) }),
  });
  await failIfBad(res);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? "";
}

/** Extrai JSON de uma resposta que pode vir com cercas de código ou texto em volta. */
export function extractJson(text: string): unknown {
  const cleaned = text.replace(/```(?:json)?/gi, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new HttpError(502, "invalid", "A IA devolveu um formato inesperado. Tente novamente.");
  try { return JSON.parse(cleaned.slice(start, end + 1)); }
  catch { throw new HttpError(502, "invalid", "A IA devolveu um JSON inválido. Tente novamente."); }
}

/** Streaming: devolve um ReadableStream que emite só o texto, trecho a trecho. */
export async function streamText(opts: {
  system: string; messages: Msg[]; maxTokens?: number; signal?: AbortSignal;
  onDone?: (full: string) => Promise<void>;
}): Promise<ReadableStream<Uint8Array>> {
  const c = getConfig();
  const maxTokens = opts.maxTokens ?? 2048;
  const res = c.provider === "anthropic"
    ? await fetch(`${c.baseUrl}/v1/messages`, {
        method: "POST", headers: anthropicHeaders(c), signal: opts.signal,
        body: JSON.stringify({ model: c.model, max_tokens: maxTokens, system: opts.system, messages: opts.messages, stream: true }),
      })
    : await fetch(`${c.baseUrl}/chat/completions`, {
        method: "POST", headers: openaiHeaders(c), signal: opts.signal,
        body: JSON.stringify({ model: c.model, max_tokens: maxTokens, stream: true,
          messages: [{ role: "system", content: opts.system }, ...opts.messages] }),
      });
  await failIfBad(res);
  if (!res.body) throw new HttpError(502, "unknown", "Resposta vazia da IA.");

  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  const reader = res.body.getReader();
  let buffer = "";
  let full = "";

  return new ReadableStream({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) {
        try { await opts.onDone?.(full); } catch (e) { console.error("onDone falhou:", e); }
        controller.close();
        return;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const evt = JSON.parse(data);
          const piece: string | undefined = c.provider === "anthropic"
            ? (evt.type === "content_block_delta" ? evt.delta?.text : undefined)
            : evt.choices?.[0]?.delta?.content;
          if (piece) { full += piece; controller.enqueue(encoder.encode(piece)); }
        } catch { /* linha parcial/keep-alive: ignora */ }
      }
    },
    cancel() { reader.cancel(); },
  });
}
