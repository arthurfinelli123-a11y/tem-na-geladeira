// Utilitários HTTP, autenticação e limites compartilhados pelas Edge Functions.
import { createClient, type SupabaseClient, type User } from "npm:@supabase/supabase-js@2";

export const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export function errorResponse(e: unknown) {
  if (e instanceof HttpError) return json({ code: e.code, message: e.message }, e.status);
  console.error("Erro inesperado:", e);
  return json({ code: "unknown", message: "Erro interno. Tente novamente em instantes." }, 500);
}

export function admin(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });
}

/** Valida o JWT do usuário. Nunca confie em user_id vindo do corpo da requisição. */
export async function requireUser(req: Request): Promise<{ user: User; db: SupabaseClient }> {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "");
  if (!token) throw new HttpError(401, "unauthorized", "Faça login para continuar.");
  const db = admin();
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user) throw new HttpError(401, "unauthorized", "Sessão inválida ou expirada.");
  return { user: data.user, db };
}

export type Kind = "recipes" | "chat" | "photo" | "substitution" | "plan";
export type Plan = "free" | "premium" | "familia";

// Limites diários por plano. 0 = recurso indisponível no plano (exige upgrade).
export const LIMITS: Record<Plan, Record<Kind, number>> = {
  free:    { recipes: 5,   chat: 0,   photo: 0,  substitution: 3,   plan: 0 },
  premium: { recipes: 50,  chat: 150, photo: 20, substitution: 50,  plan: 10 },
  familia: { recipes: 120, chat: 300, photo: 50, substitution: 120, plan: 25 },
};

/** Plano efetivo: só é pago se o provedor de pagamento confirmou (subscriptions.status = 'active'). */
export async function getPlan(db: SupabaseClient, uid: string): Promise<Plan> {
  const { data } = await db.rpc("effective_plan", { uid });
  return (data as Plan) ?? "free";
}

/** Confere plano/limite e reserva 1 uso de forma atômica. Devolve função para estornar em caso de falha. */
export async function consumeUsage(db: SupabaseClient, uid: string, kind: Kind, plan: Plan) {
  const max = LIMITS[plan][kind];
  if (max === 0) {
    throw new HttpError(403, "plan", "Este recurso faz parte do plano Premium.");
  }
  const { data: ok, error } = await db.rpc("increment_usage", { uid, k: kind, max_allowed: max });
  if (error) throw error;
  if (!ok) throw new HttpError(429, "limit", `Você atingiu o limite diário do seu plano (${max}).`);
  return async () => {
    const { data } = await db.from("usage_limits").select("id,count")
      .eq("user_id", uid).eq("kind", kind).eq("day", new Date().toISOString().slice(0, 10)).maybeSingle();
    if (data && data.count > 0) await db.from("usage_limits").update({ count: data.count - 1 }).eq("id", data.id);
  };
}

/** Exige consentimento explícito para usar dados pessoais na IA. */
export async function requireConsent(db: SupabaseClient, uid: string) {
  const { data } = await db.from("profiles").select("ai_consent").eq("id", uid).maybeSingle();
  if (!data?.ai_consent) {
    throw new HttpError(403, "consent", "Autorize o uso dos seus dados pela IA para continuar.");
  }
}
