// Pós-processamento SERVER-SIDE: não confiamos cegamente na IA.
// Garante as regras críticas mesmo que o modelo erre:
//   • "have" só é verdadeiro se o item REALMENTE está na despensa (comparação estrita);
//   • alergias, restrições e itens excluídos descartam a receita;
//   • compatibilidade ("completa" vs "requer_adicional") é recalculada aqui, nunca pelo modelo;
//   • modo "nao_comprar" descarta qualquer receita com item faltando.
import type { Recipe } from "./schemas.ts";

const STOP = new Set(["de", "da", "do", "das", "dos", "e", "em", "com", "a", "o", "para", "ao", "na", "no"]);

/** Palavras de preparo/variedade que NÃO mudam o ingrediente ("tomate picado" = "tomate"). */
const OK_EXTRA = new Set([
  "picado", "picada", "fatiado", "fatiada", "ralado", "ralada", "cozido", "cozida", "fresco", "fresca", "cubo", "rodela",
  "fatia", "tira", "amassado", "amassada", "descascado", "descascada", "desfiado", "desfiada", "moido", "moida", "grande",
  "pequeno", "pequena", "medio", "media", "maduro", "madura", "inteiro", "inteira", "cru", "crua", "seco", "seca", "quente",
  "frio", "fria", "gelado", "gelada", "derretido", "derretida", "mole", "batido", "batida", "escorrido", "escorrida",
  "branco", "branca", "preto", "preta", "integral", "cereja", "italiano", "caipira", "comum", "tradicional", "refinado",
  "cristal", "roxo", "roxa", "dente", "folha", "extra", "virgem", "light", "desnatado", "desnatada", "gosto",
]);

export function norm(s: string) {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/\([^)]*\)/g, " ")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function singular(t: string): string {
  if (t.endsWith("oes") || t.endsWith("aes")) return t.slice(0, -3) + "ao"; // limões → limao, pães → pao
  if (t.length > 3 && t.endsWith("s") && !t.endsWith("ss")) return t.slice(0, -1); // tomates → tomate
  return t;
}

function tokens(s: string): string[] {
  return norm(s).split(/\s+/).filter((t) => t && !STOP.has(t)).map(singular);
}

/** Comparação FROUXA (todos os tokens de um lado aparecem no outro). Use só para EXCLUIR (conservador). */
export function matches(a: string, b: string): boolean {
  const ta = tokens(a), tb = tokens(b);
  if (!ta.length || !tb.length) return false;
  return ta.every((t) => tb.includes(t)) || tb.every((t) => ta.includes(t));
}

/**
 * Comparação ESTRITA para afirmar "você já tem": os nomes só diferem por palavras de preparo/variedade.
 * "leite" NÃO bate com "leite condensado"; "tomates picados" bate com "tomate".
 * Na dúvida devolve false — o pior caso é pedir para comprar algo que existe, nunca o contrário.
 */
export function haveMatch(recipeName: string, pantryName: string): boolean {
  const a = tokens(recipeName), b = tokens(pantryName);
  if (!a.length || !b.length) return false;
  const onlyA = a.filter((t) => !b.includes(t));
  const onlyB = b.filter((t) => !a.includes(t));
  if (!onlyA.length && !onlyB.length) return true;
  if (!onlyA.length) return onlyB.every((t) => OK_EXTRA.has(t));
  if (!onlyB.length) return onlyA.every((t) => OK_EXTRA.has(t));
  return false;
}

// ── Alergias, restrições e dietas → palavras proibidas ─────────────────────────
const MEAT = ["carne", "bife", "frango", "peito de frango", "porco", "bacon", "linguica", "salsicha", "presunto", "peixe", "atum", "salmao", "sardinha", "camarao", "bovina", "boi", "costela", "fiambre", "mortadela", "peru", "calabresa"];
const DAIRY = ["leite", "queijo", "manteiga", "iogurte", "creme de leite", "requeijao", "nata", "mussarela", "parmesao", "ricota", "leite condensado", "chantilly", "cream cheese"];
const KEYWORDS: Record<string, string[]> = {
  lactose: DAIRY,
  leite: DAIRY,
  gluten: ["trigo", "farinha de trigo", "pao", "macarrao", "massa", "aveia", "cevada", "centeio", "biscoito", "bolacha", "cuscuz de trigo", "farinha de rosca", "panko"],
  trigo: ["trigo", "farinha de trigo", "pao", "macarrao", "farinha de rosca"],
  ovo: ["ovo", "gema", "clara", "maionese"],
  amendoim: ["amendoim", "amendoins", "pacoca"],
  castanha: ["castanha", "castanha de caju", "caju", "noz", "nozes", "amendoa", "avela", "pistache", "macadamia"],
  noz: ["noz", "nozes", "amendoa", "avela", "pistache", "macadamia", "castanha"],
  "frutos do mar": ["camarao", "camaroes", "siri", "lagosta", "mexilhao", "lula", "polvo", "marisco", "ostra", "vieira"],
  marisco: ["camarao", "camaroes", "siri", "lagosta", "mexilhao", "lula", "polvo", "marisco", "ostra"],
  peixe: ["peixe", "salmao", "atum", "tilapia", "bacalhau", "sardinha", "merluza", "anchova", "pescada"],
  soja: ["soja", "shoyu", "tofu", "missô", "miso", "edamame"],
  gergelim: ["gergelim", "tahine", "tahini"],
  vegetariano: MEAT,
  vegano: [...MEAT, ...DAIRY, "ovo", "gema", "clara", "mel", "maionese", "gelatina"],
  acucar: ["acucar", "mel", "melado", "rapadura", "xarope", "leite condensado", "doce de leite"],
};

/** Termos do usuário (alergias/restrições) → o próprio termo + sinônimos/derivados. */
export function forbiddenTerms(terms: string[]): string[] {
  const out = new Set<string>();
  for (const t of terms) {
    const n = norm(t);
    if (n.length < 3) continue;
    out.add(n);
    for (const [k, v] of Object.entries(KEYWORDS)) {
      if (n.includes(k) || (n.length >= 4 && k.includes(n))) v.forEach((x) => out.add(norm(x)));
    }
  }
  return [...out];
}

/** Dietas (ex.: "Vegano", "Sem glúten"): só expandem palavras conhecidas; "Low carb" etc. não viram proibições literais. */
export function dietTerms(diets: string[]): string[] {
  const out = new Set<string>();
  for (const d of diets) {
    const n = norm(d);
    for (const [k, v] of Object.entries(KEYWORDS)) if (n.includes(k)) v.forEach((x) => out.add(norm(x)));
  }
  return [...out];
}

/** Devolve o termo proibido encontrado em `text` (palavra inteira, aceitando plural simples) ou null. */
export function findForbidden(text: string, terms: string[]): string | null {
  const n = ` ${norm(text)} `;
  for (const t of terms) {
    if (n.includes(` ${t} `) || n.includes(` ${t}s `) || n.includes(` ${t}es `)) return t;
  }
  return null;
}

export interface SafetyContext {
  pantry: string[];      // itens que o usuário TEM
  excluded: string[];    // itens que NÃO quer usar
  allergies: string[];   // alergias/restrições informadas
  diets?: string[];      // preferências alimentares do perfil (Vegano, Sem glúten…)
  mode: string | null;
}

export function enforceRules(recipes: Recipe[], ctx: SafetyContext): { recipes: Recipe[]; dropped: number } {
  const forbidden = [...new Set([...forbiddenTerms(ctx.allergies), ...dietTerms(ctx.diets ?? [])])];
  const out: Recipe[] = [];
  for (const r of recipes) {
    // 1) Alergias, dietas e itens excluídos: descarta a receita inteira se algum ingrediente (ou o título) violar.
    const violates =
      findForbidden(r.title, forbidden) !== null ||
      r.ingredients.some((ing) =>
        ctx.excluded.some((x) => matches(ing.name, x)) ||
        findForbidden(ing.name, forbidden) !== null ||
        ctx.allergies.some((al) => norm(al).length > 2 && norm(ing.name).includes(norm(al))));
    if (violates) continue;

    // 2) "have" só é verdadeiro se o item REALMENTE está na despensa do usuário (comparação estrita).
    const ingredients = r.ingredients.map((ing) => ({
      ...ing,
      have: ctx.pantry.some((p) => haveMatch(ing.name, p)),
    }));

    // 3) Modo "não quero comprar nada": qualquer item faltando invalida a receita.
    if (ctx.mode === "nao_comprar" && ingredients.some((i) => !i.have)) continue;

    // 4) Compatibilidade recalculada por nós, nunca pelo modelo.
    const missing = ingredients.filter((i) => !i.have && i.essential).map((i) => i.name);

    out.push({
      ...r,
      ingredients,
      missing_essentials: missing,
      compatibility: missing.length === 0 ? "completa" : "requer_adicional",
      allergen_warnings: [
        ...new Set([...r.allergen_warnings, ...ctx.allergies.map((a) => `Você informou restrição a: ${a}. Confira sempre os rótulos dos produtos.`)]),
      ],
      nutrition: r.nutrition ? { ...r.nutrition, approximate: true } : null,
    });
  }
  return { recipes: out, dropped: recipes.length - out.length };
}
