-- Tem na Geladeira — schema, RLS e triggers
-- Execute no SQL Editor do Supabase ou com `supabase db push`.

create extension if not exists "pgcrypto";

-- ───────────── Tipos ─────────────
do $$ begin
  create type plan_tier as enum ('free', 'premium', 'familia');
exception when duplicate_object then null; end $$;

-- ───────────── Utilitário updated_at ─────────────
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ───────────── profiles ─────────────
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  diet_preferences text[] not null default '{}',     -- ex.: vegetariano, low carb
  allergies text[] not null default '{}',            -- ex.: amendoim, lactose
  default_servings int not null default 2 check (default_servings between 1 and 20),
  favorite_ingredients text[] not null default '{}',
  disliked_ingredients text[] not null default '{}',
  equipment text[] not null default '{}',            -- ex.: forno, airfryer, micro-ondas
  ai_consent boolean not null default false,         -- permissão p/ usar dados na IA
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- ───────────── catálogo de ingredientes (seed, leitura pública) ─────────────
create table if not exists public.ingredient_catalog (
  id serial primary key,
  name text not null unique,
  category text not null check (category in (
    'carnes','frutas','verduras_legumes','graos_cereais','laticinios',
    'massas_farinhas','temperos','bebidas','outros'))
);

-- ───────────── pantry_items ─────────────
create table if not exists public.pantry_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  category text not null default 'outros',
  quantity numeric check (quantity is null or quantity >= 0),
  unit text,
  excluded boolean not null default false,           -- true = "NÃO quero usar"
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, name, excluded)
);
create index on public.pantry_items (user_id);
create trigger pantry_updated before update on public.pantry_items
  for each row execute function public.set_updated_at();

-- ───────────── recipes_generated ─────────────
create table if not exists public.recipes_generated (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null default 'geral',
  mode text,                                         -- modo especial usado
  data jsonb not null,                               -- JSON validado com Zod (ver src/lib/schemas.ts)
  image_url text,
  is_public boolean not null default false,
  share_slug text unique,
  created_at timestamptz not null default now()
);
create index on public.recipes_generated (user_id, created_at desc);

-- ───────────── favorites ─────────────
create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  recipe_id uuid not null references public.recipes_generated(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, recipe_id)
);

-- ───────────── collections ─────────────
create table if not exists public.collections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  created_at timestamptz not null default now()
);
create table if not exists public.collection_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  collection_id uuid not null references public.collections(id) on delete cascade,
  recipe_id uuid not null references public.recipes_generated(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (collection_id, recipe_id)
);

-- ───────────── chat ─────────────
create table if not exists public.chat_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Nova conversa',
  recipe_id uuid references public.recipes_generated(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null references public.chat_conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index on public.chat_messages (conversation_id, created_at);

-- ───────────── compras ─────────────
create table if not exists public.shopping_lists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Minha lista',
  archived boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.shopping_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  list_id uuid not null references public.shopping_lists(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  quantity numeric,
  unit text,
  category text not null default 'outros',
  checked boolean not null default false,
  source_recipe_id uuid references public.recipes_generated(id) on delete set null,
  created_at timestamptz not null default now()
);
create index on public.shopping_items (list_id);

-- ───────────── planejamento ─────────────
create table if not exists public.meal_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  params jsonb not null,                             -- dias, refeições, orçamento, preferências
  plan jsonb not null,                               -- saída validada da IA
  shopping_list_id uuid references public.shopping_lists(id) on delete set null,
  created_at timestamptz not null default now()
);

-- ───────────── assinaturas (escrita SOMENTE via service role/webhook) ─────────────
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  plan plan_tier not null default 'free',
  status text not null default 'inactive' check (status in ('inactive','active','past_due','canceled')),
  provider text,                                     -- ex.: stripe, mercadopago
  provider_customer_id text,
  provider_subscription_id text,
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

-- ───────────── limites de uso (escrita SOMENTE via service role) ─────────────
create table if not exists public.usage_limits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null default current_date,
  kind text not null check (kind in ('recipes','chat','photo','substitution','plan')),
  count int not null default 0,
  unique (user_id, day, kind)
);

-- Plano efetivo: só conta como pago se o provedor confirmou (status = active)
create or replace function public.effective_plan(uid uuid) returns plan_tier
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select plan from public.subscriptions where user_id = uid and status = 'active'),
    'free')
$$;

-- Incremento atômico do contador (chamado pelas Edge Functions com service role)
create or replace function public.increment_usage(uid uuid, k text, max_allowed int)
returns boolean language plpgsql security definer set search_path = public as $$
declare current_count int;
begin
  insert into public.usage_limits (user_id, day, kind, count)
  values (uid, current_date, k, 0)
  on conflict (user_id, day, kind) do nothing;

  update public.usage_limits set count = count + 1
  where user_id = uid and day = current_date and kind = k and count < max_allowed
  returning count into current_count;

  return current_count is not null;
end $$;
revoke all on function public.increment_usage(uuid, text, int) from public, anon, authenticated;
revoke all on function public.effective_plan(uuid) from public, anon;
grant execute on function public.effective_plan(uuid) to authenticated, service_role;

-- ───────────── Novo usuário → profile + assinatura free ─────────────
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
          new.raw_user_meta_data->>'avatar_url');
  insert into public.subscriptions (user_id, plan, status) values (new.id, 'free', 'inactive');
  insert into public.shopping_lists (user_id, name) values (new.id, 'Minha lista');
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ═════════════ RLS ═════════════
alter table public.profiles            enable row level security;
alter table public.ingredient_catalog  enable row level security;
alter table public.pantry_items        enable row level security;
alter table public.recipes_generated   enable row level security;
alter table public.favorites           enable row level security;
alter table public.collections         enable row level security;
alter table public.collection_items    enable row level security;
alter table public.chat_conversations  enable row level security;
alter table public.chat_messages       enable row level security;
alter table public.shopping_lists      enable row level security;
alter table public.shopping_items      enable row level security;
alter table public.meal_plans          enable row level security;
alter table public.subscriptions       enable row level security;
alter table public.usage_limits        enable row level security;

-- Catálogo: leitura para todos os usuários autenticados e anônimos (autocomplete na Home)
create policy "catalog_read" on public.ingredient_catalog for select using (true);

-- profiles (chave = id)
create policy "profiles_select" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "profiles_delete" on public.profiles for delete using (auth.uid() = id);

-- Tabelas com user_id: SELECT/INSERT/UPDATE/DELETE restritos ao dono
do $$
declare t text;
begin
  foreach t in array array[
    'pantry_items','favorites','collections','collection_items',
    'chat_conversations','chat_messages','shopping_lists','shopping_items','meal_plans'
  ] loop
    execute format('create policy %I on public.%I for select using (auth.uid() = user_id)', t||'_select', t);
    execute format('create policy %I on public.%I for insert with check (auth.uid() = user_id)', t||'_insert', t);
    execute format('create policy %I on public.%I for update using (auth.uid() = user_id) with check (auth.uid() = user_id)', t||'_update', t);
    execute format('create policy %I on public.%I for delete using (auth.uid() = user_id)', t||'_delete', t);
  end loop;
end $$;

-- recipes_generated: dono tem tudo; receitas marcadas como públicas podem ser lidas por link
create policy "recipes_select_own" on public.recipes_generated for select using (auth.uid() = user_id);
create policy "recipes_select_public" on public.recipes_generated for select using (is_public = true);
create policy "recipes_insert" on public.recipes_generated for insert with check (auth.uid() = user_id);
create policy "recipes_update" on public.recipes_generated for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "recipes_delete" on public.recipes_generated for delete using (auth.uid() = user_id);

-- Integridade entre contas: itens só podem apontar para listas/coleções/conversas do próprio usuário
create or replace function public.enforce_same_owner() returns trigger
language plpgsql as $$
declare owner uuid;
begin
  if tg_table_name = 'shopping_items' then
    select user_id into owner from public.shopping_lists where id = new.list_id;
  elsif tg_table_name = 'collection_items' then
    select user_id into owner from public.collections where id = new.collection_id;
  elsif tg_table_name = 'chat_messages' then
    select user_id into owner from public.chat_conversations where id = new.conversation_id;
  end if;
  if owner is distinct from new.user_id then
    raise exception 'Recurso pertence a outro usuário';
  end if;
  return new;
end $$;
create trigger shopping_items_owner before insert or update on public.shopping_items
  for each row execute function public.enforce_same_owner();
create trigger collection_items_owner before insert or update on public.collection_items
  for each row execute function public.enforce_same_owner();
create trigger chat_messages_owner before insert or update on public.chat_messages
  for each row execute function public.enforce_same_owner();

-- subscriptions e usage_limits: usuário só LÊ. Escrita apenas por service role (webhook do
-- gateway / Edge Functions). Assim ninguém consegue se auto-conceder um plano pago.
create policy "subscriptions_select" on public.subscriptions for select using (auth.uid() = user_id);
create policy "usage_select" on public.usage_limits for select using (auth.uid() = user_id);

-- ═════════════ Storage ═════════════
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true)
  on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('photos', 'photos', false)
  on conflict (id) do nothing;

-- Pasta = uid do usuário: avatars/<uid>/arquivo, photos/<uid>/arquivo
create policy "avatars_read" on storage.objects for select using (bucket_id = 'avatars');
create policy "avatars_write" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_update" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "photos_read" on storage.objects for select to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "photos_write" on storage.objects for insert to authenticated
  with check (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "photos_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
