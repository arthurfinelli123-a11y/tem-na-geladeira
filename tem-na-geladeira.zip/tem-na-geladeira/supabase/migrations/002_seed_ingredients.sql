-- Seed do catálogo de ingredientes (autocomplete). Idempotente.
insert into public.ingredient_catalog (name, category) values
-- carnes
('Frango (peito)','carnes'),('Frango (coxa)','carnes'),('Carne moída','carnes'),('Patinho','carnes'),
('Acém','carnes'),('Costela bovina','carnes'),('Bife','carnes'),('Linguiça','carnes'),
('Bacon','carnes'),('Presunto','carnes'),('Salsicha','carnes'),('Carne de porco','carnes'),
('Tilápia','carnes'),('Sardinha','carnes'),('Atum (lata)','carnes'),('Camarão','carnes'),
('Ovo','carnes'),('Peru (peito)','carnes'),
-- frutas
('Banana','frutas'),('Maçã','frutas'),('Laranja','frutas'),('Limão','frutas'),('Mamão','frutas'),
('Abacate','frutas'),('Morango','frutas'),('Uva','frutas'),('Abacaxi','frutas'),('Manga','frutas'),
('Melancia','frutas'),('Maracujá','frutas'),('Pera','frutas'),('Coco ralado','frutas'),('Goiaba','frutas'),
-- verduras/legumes
('Cebola','verduras_legumes'),('Alho','verduras_legumes'),('Tomate','verduras_legumes'),
('Batata','verduras_legumes'),('Batata-doce','verduras_legumes'),('Cenoura','verduras_legumes'),
('Abobrinha','verduras_legumes'),('Abóbora','verduras_legumes'),('Brócolis','verduras_legumes'),
('Couve','verduras_legumes'),('Couve-flor','verduras_legumes'),('Alface','verduras_legumes'),
('Espinafre','verduras_legumes'),('Pepino','verduras_legumes'),('Pimentão','verduras_legumes'),
('Berinjela','verduras_legumes'),('Milho verde','verduras_legumes'),('Ervilha','verduras_legumes'),
('Mandioca','verduras_legumes'),('Chuchu','verduras_legumes'),('Beterraba','verduras_legumes'),
('Repolho','verduras_legumes'),('Cogumelo','verduras_legumes'),('Cebolinha','verduras_legumes'),
('Salsinha','verduras_legumes'),('Coentro','verduras_legumes'),('Gengibre','verduras_legumes'),
-- grãos/cereais
('Arroz','graos_cereais'),('Arroz integral','graos_cereais'),('Feijão carioca','graos_cereais'),
('Feijão preto','graos_cereais'),('Lentilha','graos_cereais'),('Grão-de-bico','graos_cereais'),
('Aveia','graos_cereais'),('Quinoa','graos_cereais'),('Milho de pipoca','graos_cereais'),
('Granola','graos_cereais'),('Amendoim','graos_cereais'),('Castanha-do-pará','graos_cereais'),
('Castanha de caju','graos_cereais'),('Pão de forma','graos_cereais'),('Pão francês','graos_cereais'),
('Tapioca (goma)','graos_cereais'),('Cuscuz (flocão)','graos_cereais'),
-- laticínios
('Leite','laticinios'),('Leite condensado','laticinios'),('Creme de leite','laticinios'),
('Manteiga','laticinios'),('Queijo mussarela','laticinios'),('Queijo minas','laticinios'),
('Queijo parmesão','laticinios'),('Requeijão','laticinios'),('Iogurte natural','laticinios'),
('Cream cheese','laticinios'),('Leite de coco','laticinios'),
-- massas/farinhas
('Macarrão espaguete','massas_farinhas'),('Macarrão parafuso','massas_farinhas'),
('Farinha de trigo','massas_farinhas'),('Farinha de mandioca','massas_farinhas'),
('Fubá','massas_farinhas'),('Amido de milho','massas_farinhas'),('Farinha de rosca','massas_farinhas'),
('Fermento em pó','massas_farinhas'),('Fermento biológico','massas_farinhas'),('Açúcar','massas_farinhas'),
('Açúcar mascavo','massas_farinhas'),('Chocolate em pó','massas_farinhas'),('Cacau em pó','massas_farinhas'),
('Massa de pastel','massas_farinhas'),('Lasanha (massa)','massas_farinhas'),('Polvilho','massas_farinhas'),
-- temperos
('Sal','temperos'),('Pimenta-do-reino','temperos'),('Azeite','temperos'),('Óleo de soja','temperos'),
('Vinagre','temperos'),('Molho de soja','temperos'),('Orégano','temperos'),('Colorau','temperos'),
('Cominho','temperos'),('Canela','temperos'),('Louro','temperos'),('Páprica','temperos'),
('Molho de tomate','temperos'),('Extrato de tomate','temperos'),('Maionese','temperos'),
('Mostarda','temperos'),('Ketchup','temperos'),('Caldo de legumes','temperos'),('Mel','temperos'),
('Noz-moscada','temperos'),('Cúrcuma','temperos'),('Baunilha','temperos'),
-- bebidas
('Café','bebidas'),('Chá','bebidas'),('Suco de laranja','bebidas'),('Água com gás','bebidas'),
('Vinho tinto','bebidas'),('Cerveja','bebidas'),('Leite de amêndoas','bebidas'),
-- outros
('Chocolate meio amargo','outros'),('Gelatina','outros'),('Biscoito maisena','outros'),
('Goiabada','outros'),('Azeitona','outros'),('Milho em conserva','outros'),('Palmito','outros'),
('Sardinha em lata','outros'),('Pasta de amendoim','outros'),('Coco (flocos)','outros')
on conflict (name) do nothing;
